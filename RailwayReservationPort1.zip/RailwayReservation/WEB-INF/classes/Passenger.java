import java.io.*;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;


public class Passenger  {
	private String name;
	private String dob;
	private int addressId;
	private String email;
	private int id;
	private int loginId;
	private Address address;
	
	
	public Passenger(String name, String date, int addressId, String email) {
		this.name = name;
		
		this.dob = date;
		this.addressId = addressId;
		this.email = email;
	}
	
//	public static String getPnr() {
//		String date = String.valueOf(LocalDateTime.now());
//		String pnr = date.substring(0, 4) + date.substring(5, 7) + date.substring(8, 10) + date.substring(11, 13)
//					+ date.substring(14, 16) + date.substring(17, 19);
//		return pnr;
//	}
	
	public  int[] stringToDate(String dob) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		Date date = (Date) formatter.parse(dob);
		Instant instant = date.toInstant();
		ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
		LocalDate givenDate = zone.toLocalDate();
		Period period = Period.between(givenDate, LocalDate.now());
		return new int[] { period.getYears(), period.getMonths(), period.getDays() };
	}
	
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDob() {
		return dob;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

}
