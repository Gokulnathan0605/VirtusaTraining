import java.io.*;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.ArrayList;



public class BookingDetail implements Serializable{

	private int trainId;
	private int passengerId;
	private float cost;
	private static String startingPoint;
	private static String endingPoint;
	private String date;

	private String pnr;
	private static String bookingStatus;
	private int startNo, endNo;
	private Train t;
	private static String routeAreas;
	private TrainService ts = new TrainService();
	private BookingService bs = new BookingService();

	public BookingDetail(int trainId, int passengerId, String pnr, float cost, String date, String startingPoint,
			String endingPoint, String bookingStatus, int startNo, int endNo) {
		this.trainId = trainId;
		this.passengerId = passengerId;
		this.cost = cost;
		BookingDetail.startingPoint = startingPoint;
		BookingDetail.endingPoint = endingPoint;
		this.date = date;
		this.bookingStatus = bookingStatus;
		this.startNo = startNo;
		this.endNo = endNo;
		this.pnr = pnr;

	}

	public BookingDetail(int trainId, int passengerId, int noOfSeats, String date, String sp, String ep) {
		this.trainId = trainId;
		this.passengerId = passengerId;
		this.cost = noOfSeats * 140;
		startingPoint = sp;
		endingPoint = ep;
		this.date = date;
		this.pnr = generatePnr();
		t = ts.readTrainDetail(MysqlConnection.getConnection(), trainId);
		int seatCount = bs.checkingBookingSeat(MysqlConnection.getConnection(), date, trainId);
		if (noOfSeats <= t.getNoOfSeats() - seatCount) {
			this.bookingStatus = "confirm";
		} else if (noOfSeats > t.getNoOfSeats() - seatCount && noOfSeats <= t.getNoOfSeats() - seatCount + 2) {
			this.bookingStatus = "waiting";
		}
		routeAreas = t.getRouteAreas();
		int[] point = findPoints(sp, ep);
		this.startNo = point[0];
		this.endNo = point[1];
	}
	
	public BookingDetail(int trainId, int passengerId, int noOfSeats, String date, String sp, String ep, String pnr) {
		this.trainId = trainId;
		this.passengerId = passengerId;
		this.cost = noOfSeats * 140;
		startingPoint = sp;
		endingPoint = ep;
		this.date = date;
		this.pnr = pnr;
		t = ts.readTrainDetail(MysqlConnection.getConnection(), trainId);
		int seatCount = bs.checkingBookingSeat(MysqlConnection.getConnection(), date, trainId);
		System.out.println(t.getNoOfSeats() + " " + seatCount);
		if (noOfSeats <= t.getNoOfSeats() - seatCount) {
			this.bookingStatus = "confirm";
		} else if (noOfSeats > t.getNoOfSeats() - seatCount && noOfSeats <= t.getNoOfSeats() - seatCount + 2) {
			this.bookingStatus = "waiting";
		}
		routeAreas = t.getRouteAreas();
		int[] point = findPoints(sp, ep);
		this.startNo = point[0];
		this.endNo = point[1];
	}

	public static String generatePnr() {
		String date = String.valueOf(LocalDateTime.now());
		String pnr = date.substring(0, 4) + date.substring(5, 7) + date.substring(8, 10) + date.substring(11, 13)
					+ date.substring(14, 16) + date.substring(17, 19) + "002";
		return pnr;
	}
	/*public static String checkSeat(int trainId) {
		Connection con = MysqlConnection.getConnection();
		ArrayList<BookingDetail> arr = BookingService.readAllDetails(con, trainId);
		int[] point = findPoints(startingPoint, endingPoint);
		int startNum = point[0], endNum = point[1];
		String res = "waiting";

		for (BookingDetail bd : arr) {
			if (bd.getBookingStatus().equals("confirm")) {
				if (bookingStatus.equals("waiting")) {
					if (!(bd.getStartNo() >= startNum || bd.getEndNo() <= endNum)) {
						res = "confirm";
						break;
					}
				}

			}
		}
		return res;

	}*/
	public static int[] findPoints(String start, String end) {
		String[] place = routeAreas.split(",");
		int first = 0, last = 0;
		for (int i = 0; i < place.length; i++) {
			if (place[i].toLowerCase().equals(start.toLowerCase())) {
				first = i;
			}
			if (place[i].toLowerCase().equals(end.toLowerCase())) {
				last = i;
			}

		}

		return new int[] { first, last };
	}

	public int getStartNo() {
		return startNo;
	}

	public void setStartNo(int startNo) {
		this.startNo = startNo;
	}

	public int getEndNo() {
		return endNo;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public void setEndNo(int endNo) {
		this.endNo = endNo;
	}

	public int getTrainId() {
		return trainId;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public String getStartingPoint() {
		return startingPoint;
	}

	public void setStartingPoint(String startingPoint) {
		BookingDetail.startingPoint = startingPoint;
	}

	public String getEndingPoint() {
		return endingPoint;
	}

	public void setEndingPoint(String endingPoint) {
		BookingDetail.endingPoint = endingPoint;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

}