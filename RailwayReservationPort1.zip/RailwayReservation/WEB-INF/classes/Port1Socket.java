import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.simple.JSONObject;
import java.sql.ResultSet;
public class Port1Socket {
	
	public static void main(String[] args) throws Exception{
			//JSONObject obj = new JSONObject();
			ArrayList<JSONObject> trainList = new ArrayList<>();
			TrainService ts = new TrainService();
			ResultSet rs = ts.readAll(MysqlConnection.getConnection());
			while(rs.next()) {
				JSONObject obj = new JSONObject();
				obj.put("trainName","aaaaa");
				obj.put("trainNumber","11111");
				obj.put("noOfSeats","5");
				obj.put("areas","asdasf");
				trainList.add(obj);
				obj = new JSONObject();
				obj.put("trainName","vvvv");
				obj.put("trainNumber","3252345");
				obj.put("noOfSeats","4");
				obj.put("areas","thkjfghjf");
				trainList.add(obj);
				trainList.add(obj);
				System.out.println(rs.getInt("trainNumber"));
			}
			System.out.println(trainList);
			for(JSONObject o : trainList) {
			System.out.println(o.get("trainName"));
			}
         // end of while
    }
}