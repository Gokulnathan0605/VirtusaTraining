import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import javax.servlet.http.*;
import org.w3c.dom.*;
import java.io.*;  
import java.util.*;
import java.sql.*;
import java.net.*;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.nio.charset.StandardCharsets;


public class MyServletContextAttributeListener implements HttpSessionAttributeListener   {
	
	private PortTransferService pts = new PortTransferService();
	private Connection con = MysqlConnection.getConnection();
	private HashMap<String, Object> mapLog = new HashMap<>();
	private	HashMap<String, Object> mapPas = new HashMap<>();
	
	public void attributeAdded(HttpSessionBindingEvent  scae) {
		HttpSession ses = scae.getSession();
		//System.out.println("Class: " + scae.getClass());
		/*if(scae.getName().equals("className")) {
			HashMap<String, Object> mapLog = new HashMap<>();
			HashMap<String, Object> mapPas = new HashMap<>();
			switch((String)scae.getValue()) {
				case "LoginServlet":
					//mapLog.put(scae.getName(),scae.getValue());
					mapLog.put("email",ses.getAttribute("email"));
					mapLog.put("password",ses.getAttribute("password"));
					break;
				case "PassengerServlet":
					
					break;
			}
			try {
			updateNodeValue(mapLog, "login");
			System.out.println(mapLog);
			} catch(Exception e) {
			}
		}*/
		//System.out.println("Attribute added " + scae.getName() + " : " + scae.getValue());
	}
	
	public void attributeReplaced(HttpSessionBindingEvent scae) {
		HttpSession ses = scae.getSession();
		if(((String)ses.getAttribute("className")).equals("LoginServlet")) {
			System.out.println("New Session");
			mapPas = new HashMap<>();
		}
		//if(scae.getName().equals("className")) {
			
			
				//ses.setAttribute("objectAlteredPort1", "Yes");
			
				switch((String)ses.getAttribute("className")) {
					case "LoginServlet":
						//System.out.println("LoginServlet");
						//mapLog.put(scae.getName(),scae.getValue());
						//mapLog.put(scae.getName(),ses.getAttribute(scae.getName()));
						//mapLog.put("password",ses.getAttribute("password"));
						break;
					case "PassengerServlet":
						if(!((String)scae.getName()).equals("className")) {
							//System.out.println("inside PassengerServlet");
							mapPas.put(scae.getName(),ses.getAttribute(scae.getName()));
						}
						break;
				}
			
			try {
			//updateNodeValue(mapLog, "login");
			mapPas.put("email", ses.getAttribute("email"));
			//System.out.println(mapPas);
			//System.out.println(mapLog);
			if(mapPas.size() > 1) {
			toanother((String)ses.getAttribute("className"), mapPas);
			}
			} catch(Exception e) {
			}
		//
		//System.out.println("Class: " + scae.getClass());
		System.out.println(scae.getName() + " : " + scae.getValue());
	}
	
	public void toanother(String name, HashMap<String, Object> arr) throws Exception{
		int[] portNumber = new int[2];
		portNumber[0] = 8081;
		portNumber[1] = 9999;
		for(int i = 0; i < 2; i++) {
			toAnotherPort(name, arr, portNumber[i]);
		}
	}
	public void toAnotherPort(String className, HashMap<String, Object> arr, int portNumber) throws Exception {
		String arg = "";
		String method = className.replace("Servlet","");
		System.out.println("Servlet: " + className + " Port: " + portNumber + " Arguments: " + arr); 
		if(pts.hostAvailabilityCheck("0.0.0.0",portNumber)) {
			String u = "http://www.kiruthicrailwayReservation.com:"+String.valueOf(portNumber)+"/"+className+"?query=changedValues&";
			for (Map.Entry<String,Object> entry : arr.entrySet()) {
				u += entry.getKey() + "=" + entry.getValue() + "&";
				arg += entry.getValue() + ","; 
			}				
			arg = arg.substring(0, arg.length() - 1);
			u = u.substring(0,u.length() - 1);
			if(u.contains(" ")) {
				u = u.replace(" ", "_");
				u += "&spaceAltered=true";
			}
			pts.addPortUpdate(con, arg, method, portNumber);
					System.out.println(u );
			URLConnection url = new URL(u).openConnection();
			HttpURLConnection http = (HttpURLConnection)url;
			http.setRequestMethod("POST");
			http.setDoOutput(true);
			try {
				
					int count = 0;
				while((count = pts.checkPortUpdate(con, method,portNumber)) != 0) {
					ResultSet rs = pts.getPortUpdate(con, method, portNumber);
					String arguments="";
					if(rs.next()) {
						arguments = rs.getString("parameters");
					}
					pts.deletePortUpdate(con, rs.getInt("id"));
					String[] res = arguments.split(",");
					Map<String, String> argu = new HashMap<>();
					argu.put("newEmail",res[0]);
					argu.put("newPass",res[1]);
					StringJoiner sj = new StringJoiner("&");
					for(Map.Entry<String, String> entry : argu.entrySet()) {
						sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
								+ URLEncoder.encode(entry.getValue(), "UTF-8"));
					}
					byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
					int length = out.length;
					
					http.setFixedLengthStreamingMode(length);
					http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
					http.connect();
					try(OutputStream os = http.getOutputStream()) {
						os.write(out);
					} catch (Exception e) {
						throw new IllegalStateException(e);
					}
				}
				
			}catch (Exception e) {
						throw new IllegalStateException(e);
			}
			http.disconnect();
		} else {
			
			pts.addPortUpdate(con, arg, method, portNumber);
			
		}
	}
	
	/*public static void updateNodeValue(HashMap<String, Object> map, String className) throws Exception {
		File file = new File("C:\\Program Files\\Apache Software Foundation\\Port1\\conf\\tables.xml");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(file);
		doc.getDocumentElement().normalize();
		
		 NodeList nodeListLogin = doc.getElementsByTagName(className);
		 
		for(int i = 0; i < nodeListLogin.getLength(); i++) {
			
			Node node = nodeListLogin.item(i);
			System.out.println("Node name: " + node.getNodeName());
			
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				Element e = (Element) node;
				
				e.getElementsByTagName("email").item(0).setTextContent((String)map.get("email"));
				e.getElementsByTagName("password").item(0).setTextContent((String)map.get("password"));
				
				//e.getElementsByTagName("loginId").item(0).setTextContent("01");
			}
			
		}
		doc.getDocumentElement().normalize();
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(file);
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
		System.out.println("XML file updated successfully");
	 }*/
}