import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

public class ParentObject {
	private Map<String, Object> object;
	private Passenger p;
	private Login l;
	private Address a;
	private BookingDetail b;
	private ObjectMapper mapper = new ObjectMapper();
	
	public void setObjectMap(Map<String, Object> object) {
		this.object = object;
		if(object.equals("")) {
			setObjectType();
		}
	}
	
	public Map<String, Object> getObjectMap(Object obj) {
		getObjectType(obj);
		return object;
	}
	
	public void getObjectType(Object obj) {
		object = mapper.convertValue(obj, new TypeReference<Map<String, Object>>() {});
	}
	
	public void setObjectType() {
		
		switch(object.size()) {
			case 4:
				p = mapper.convertValue(object, Passenger.class);
				break;
			case 2:
				l = mapper.convertValue(object, Login.class);
				break;
			case 3:
				a = mapper.convertValue(object, Address.class);
				break;
			case 7:
				b = mapper.convertValue(object, BookingDetail.class);
				break;
		}
		
	}
}