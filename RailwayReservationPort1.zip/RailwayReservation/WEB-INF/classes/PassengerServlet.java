import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.sql.*;
import java.text.ParseException;
import javax.servlet.ServletContext;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.nio.charset.StandardCharsets;
import com.google.gson.Gson; 
import org.json.simple.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import org.json.simple.parser.*;
/**
 * Servlet implementation class PassengerServlet
 */
@WebServlet("/PassengerServlet")
public class PassengerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PassengerService passengerService = new PassengerService();
	private Connection con = MysqlConnection.getConnection();
	private AddressService as = new AddressService();
	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private InputStream is;
	private int loginId;
	private  ArrayList<JSONObject> passengerList = new ArrayList<>();
	private Passenger p;
	private Address ad;
	private PortTransferService pts = new PortTransferService();
	
	
	/**
	 * Default constructor.
	 */
	public PassengerServlet() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		if(request.getQueryString() != null) {
			String json="";
			try {
				if(request.getParameter("query").equals("allHoldPassenger")) {
					int port = Integer.parseInt(request.getParameter("port"));
					ResultSet rs = pts.getPortUpdate(con, "Passneger", port);
					JSONArray arr = new JSONArray();
					while(rs.next()) {
						String arguments = rs.getString("parameters");
						String[] res = arguments.split(",");
						JSONObject obj = new JSONObject();
						obj.put("id", rs.getInt("id"));
						obj.put("name",res[0]);
						obj.put("email",res[1]);
						obj.put("date",res[2]);
						obj.put("street",res[3]);
						obj.put("city",res[4]);
						obj.put("postalCode",res[5]);	
						arr.add(obj);
						pts.deletePortUpdate(con, rs.getInt("id"));
					}
					
					json = arr.toString();
				}
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				out.print(json);
				out.flush();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
		} else {		
			String inputLine;
			JSONParser parser = new JSONParser();
			ArrayList<Passenger> arr = new ArrayList<>();
			try {
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/PassengerServlet?port=8080&query=allHoldPassenger");
					URLConnection yc = urlLogin.openConnection();
					BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
					
					while ((inputLine = in.readLine()) != null) {     
						JSONArray a = (JSONArray) parser.parse(inputLine);
						for (Object o : a) {
							JSONObject obj = (JSONObject) o;
							
							Long l1 = new Long((Long)obj.get("id"));
							Long l3 = new Long((Long)obj.get("loginId"));
							Long pos = new Long((Long)obj.get("postalCode"));
							ad = new Address((String)obj.get("street"), (String)obj.get("city"), pos.intValue());
							int adId = as.createAddress(ad,con);
							ad.setId(adId);
							p = new Passenger((String)obj.get("name"),(String)obj.get("dob"),adId,(String)obj.get("email"));
							p.setId(l1.intValue());
							p.setLoginId(l3.intValue());
							p.setAddress(ad);
							arr.add(p);
							
						}
					}
				}
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/PassengerServlet?port=8080&query=allHoldPassenger");
					URLConnection yc1 = urlLogin1.openConnection();
					BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
					while ((inputLine = in1.readLine()) != null) {     
						JSONArray a = (JSONArray) parser.parse(inputLine);
						for (Object o : a) {
							JSONObject obj = (JSONObject) o;
							
							Long l1 = new Long((Long)obj.get("id"));
							Long l3 = new Long((Long)obj.get("loginId"));
							Long pos = new Long((Long)obj.get("postalCode"));
							ad = new Address((String)obj.get("street"), (String)obj.get("city"), pos.intValue());
							int adId = as.createAddress(ad,con);
							ad.setId(adId);
							p = new Passenger((String)obj.get("name"),(String)obj.get("dob"),adId,(String)obj.get("email"));
							p.setId(l1.intValue());
							p.setLoginId(l3.intValue());
							p.setAddress(ad);
							arr.add(p);
							
						}
					}
				}
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			passengerService.createHoldPassenger(con, arr);
		
			RequestDispatcher dispatcher = request.getRequestDispatcher("WelcomePage.jsp");
			dispatcher.forward(request, response);
		//}
		//RequestDispatcher dispatcher = request.getRequestDispatcher("WelcomePage.jsp");
		//	dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//loginId = (int)request.getSession().getAttribute("loginId");
		
		/*if(passengerService.checkPassenger(con, loginId) > 0) {
				Passenger p = passengerService.getPassenger(con, loginId);
				Address a = as.readAddress(p.getAddressId(), con);
				//System.out.println("passenger Name : " + p.getName() + "address: " + a.getCity());
				request.getSession().setAttribute("pasName",p.getName());
				request.getSession().setAttribute("pasDob", p.getDob());
				request.getSession().setAttribute("addStreet", a.getStreet());
				request.getSession().setAttribute("addCity", a.getCity());
				request.getSession().setAttribute("addPostalCode", a.getPostalCode());
				
		} else {
			request.getSession().setAttribute("pasName","");
				request.getSession().setAttribute("pasDob", "");
				request.getSession().setAttribute("addStreet", "");
				request.getSession().setAttribute("addCity", "");
				request.getSession().setAttribute("addPostalCode", "");
		}*/
		//getDataFromPort2();
		if(request.getQueryString() != null) {
			try {
				String query = request.getParameter("query");
				if(query.equals("updatePassenger")) {
					String name = request.getParameter("name");
					String email = request.getParameter("email");
					String date = request.getParameter("date");
					String street = request.getParameter("street");
					String city = request.getParameter("city");
					int logId = passengerService.checkLogin(con, email);
					Integer postalCode = Integer.parseInt(request.getParameter("postalCode"));
					Address newAdd = new Address(street, city, postalCode);
					int addId = as.createAddress(newAdd, con);
					Passenger newPas = new Passenger(name, date, addId, email);
					passengerService.createPassenger(newPas, newAdd, logId, con);
				}
				if(query.equals("changedValues")) {
					HashMap<String, String> map = new HashMap<>();
					String queryString = request.getQueryString();
					System.out.println(queryString);
					String[] str = queryString.split("&");
					for(String i : str) {
						if(!i.contains("query")) {
							String[] s = i.split("=");
							map.put(s[0],s[1]);
						}
					}
					System.out.println("Values " + map + " to be updated in PORT 8080");
					passengerService.updateParticularDetails(con, map);
				}
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
			
		} else {
			
			request.getSession().setAttribute("className",this.getClass().getSimpleName());
			String name = request.getParameter("name");
			if(!name.equals((String)request.getSession().getAttribute("pasName"))) {
				request.getSession().setAttribute("pasName",name);
			}
			HttpSession session = request.getSession(true);
			//session.setAttribute("passengerName", name);
			String date = request.getParameter("dob");
			if(!date.equals((String)request.getSession().getAttribute("pasDob"))) {
				request.getSession().setAttribute("pasDob",date);
			}
			String email = request.getParameter("email");
			String street = request.getParameter("street");
			if(!street.equals((String)request.getSession().getAttribute("addStreet"))) {
				request.getSession().setAttribute("addStreet",street);
			}
			String city = request.getParameter("city");
			if(!city.equals((String)request.getSession().getAttribute("addCity"))) {
				request.getSession().setAttribute("addCity",city);
			}
			int postalCode = Integer.parseInt(request.getParameter("postalCode"));
			System.out.println(postalCode + " : postalCode");
			//System.out.println((int) request.getSession().getAttribute("addPostalCode") + " :session postalCode");
			try{
			if(postalCode != (int) request.getSession().getAttribute("addPostalCode")) {
				request.getSession().setAttribute("addPostalCode", postalCode);
			}
			}catch(Exception e) {
				
			}
			loginId = passengerService.checkLogin(con, email);
			
		//	if(!session.getAttribute("objectAlteredPort1").equals("Yes")) {
			Address address = new Address(street, city, postalCode);
			int addressId = as.createAddress(address, con);
			Passenger passenger = new Passenger(name, date, addressId, email);
			passenger.setAddress(address);
			passengerService.createPassenger(passenger, address, loginId, con);
		//	}
			
			try {
				
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
						String u1 = "http://www.kiruthicrailwayReservation.com:8081/PassengerServlet?query=updatePassenger&email="+email+
						"&name"+name+"&date="+date+"&street="+street+"&city="+city+"&postalCode="+postalCode;
						
						u1=u1.replace(" ","_");
						//System.out.println("Post Url:" + u1);
						pts.addPortUpdate(con,name+","+email+","+date+","+street+","+city+","+postalCode , "Passenger", 8081);
						URLConnection url1 = new URL(u1).openConnection();
						HttpURLConnection http1 = (HttpURLConnection)url1;
						http1.setRequestMethod("POST");
						http1.setDoOutput(true);
						try {
							int count = 0;
							while((count = pts.checkPortUpdate(con, "Passenger",8081)) != 0) {
								ResultSet rs = pts.getPortUpdate(con, "Passenger", 8081);
								String arguments="";
								if(rs.next()) {
									arguments = rs.getString("parameters");
								}
								pts.deletePortUpdate(con, rs.getInt("id"));
								String[] res = arguments.split(",");
								Map<String, String> arg = new HashMap<>();
								System.out.println(Arrays.toString(res));
								arg.put("name",res[0]);
								arg.put("email",res[1]);
								arg.put("date",res[2]);
								arg.put("street",res[3]);
								arg.put("city",res[4]);
								arg.put("postalCode",res[5]);
								
								StringJoiner sj = new StringJoiner("&");
								for(Map.Entry<String, String> entry : arg.entrySet()) {
									sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
											+ URLEncoder.encode(entry.getValue(), "UTF-8"));
								}
								byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
								int length = out.length;
								
								http1.setFixedLengthStreamingMode(length);
								http1.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
								http1.connect();
								try(OutputStream os = http1.getOutputStream()) {
									os.write(out);
								} catch (Exception e) {
									throw new IllegalStateException(e);
								}
							}
						}catch (Exception e) {
									throw new IllegalStateException(e);
						}
						http1.disconnect();
						
					} else {
						String arguments = name+","+email+","+date+","+street+","+city+","+postalCode ;
						pts.addPortUpdate(con, arguments, "Passenger", 8081);
						
					}
					if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
						String u2 = "http://www.kiruthicrailwayReservation.com:9999/PassengerServlet?query=updatePassenger&email="+email+
						"&name"+name+"&date="+date+"&street="+street+"&city="+city+"&postalCode="+postalCode;
						

						pts.addPortUpdate(con,name+","+email+","+date+","+street+","+city+","+postalCode , "Passenger", 9999);

						u2=u2.replace(" ","_");
						//System.out.println("Post Url:" + u2);
						
						URLConnection url2 = new URL(u2).openConnection();
						HttpURLConnection http2 = (HttpURLConnection)url2;
						http2.setRequestMethod("POST");
						
						http2.setDoOutput(true);
						try {
							int count = 0;
							while((count = pts.checkPortUpdate(con, "Passenger",9999)) != 0) {
								ResultSet rs = pts.getPortUpdate(con, "Passenger", 9999);
								String arguments="";
								if(rs.next()) {
									arguments = rs.getString("parameters");
								}
								pts.deletePortUpdate(con, rs.getInt("id"));
								String[] res = arguments.split(",");
								Map<String, String> arg = new HashMap<>();
								arg.put("name",res[0]);
								arg.put("email",res[1]);
								arg.put("date",res[2]);
								arg.put("street",res[3]);
								arg.put("city",res[4]);
								arg.put("postalCode",res[5]);
								StringJoiner sj = new StringJoiner("&");
								for(Map.Entry<String, String> entry : arg.entrySet()) {
									sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
											+ URLEncoder.encode(entry.getValue(), "UTF-8"));
								}
								byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
								int length = out.length;
								
								http2.setFixedLengthStreamingMode(length);
						
								http2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
								http2.connect();
								
								try(OutputStream os = http2.getOutputStream()) {
									os.write(out);
								} catch (Exception e) {
									throw new IllegalStateException(e);
								}
								
							}
						}catch (Exception e) {
									throw new IllegalStateException(e);
						}
						http2.disconnect();
						
						
					} else {
						String arguments = name+","+email+","+date+","+street+","+city+","+postalCode ;
						pts.addPortUpdate(con, arguments, "Passenger", 9999);
						
					}
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
			
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher("WelcomePage.jsp");
			requestDispatcher.forward(request, response);
		}
	}
	/*public JSONArray getAllPassenger() throws Exception {
		ResultSet rs = passengerService.readAllPassenger(con);
		JSONArray arr = new JSONArray();
		while(rs.next()) {
			JSONObject obj = new JSONObject();
			obj.put("name",rs.getString("passengerName"));
			obj.put("id",rs.getInt("id"));
			obj.put("dob",rs.getString("dateOfBirth"));
			obj.put("addressId",rs.getInt("addressId"));
			obj.put("email",rs.getString("email"));
			obj.put("loginId",rs.getInt("loginId"));
			arr.add(obj);
		}
		return arr;
	}
	public JSONArray getAllLogin() throws Exception {
		ResultSet rs = passengerService.readAllLogin(con);
		JSONArray arr = new JSONArray();
		while(rs.next()) {
			JSONObject obj = new JSONObject();
			obj.put("password",rs.getString("password"));
			obj.put("id",rs.getInt("id"));
			obj.put("email",rs.getString("email"));		
			arr.add(obj);
		}
		return arr;
	}
	public JSONArray getAllAddress() throws Exception {
		ResultSet rs = as.readAll(con);
		JSONArray arr = new JSONArray();
		while(rs.next()) {
			JSONObject obj = new JSONObject();
			obj.put("id",rs.getInt("id"));
			obj.put("street",rs.getString("street"));
			obj.put("postalCode",rs.getInt("postalCode"));
			obj.put("city",rs.getString("city"));		
			arr.add(obj);
		}
		
		return arr;
	}
	public JSONObject getAddress(int id) throws Exception {
		Address res = as.readAddress(id,con);
		JSONObject obj = new JSONObject();
		obj.put("street",res.getStreet());
		obj.put("postalCode",res.getPostalCode());
		obj.put("city",res.getCity());		
		return obj;
	}
	public JSONObject getLogin(String e) throws Exception {
		Login res = passengerService.readLogin(con, e);
		JSONObject obj = new JSONObject();
		obj.put("email",res.getEmail());
		obj.put("id",res.getId());
		obj.put("password",res.getPassword());		
		return obj;
	}
	public JSONObject getPassenger(int id) throws Exception {
		Passenger res = passengerService.getPassenger(con, id);
		JSONObject obj = new JSONObject();
		obj.put("name",res.getName());
			obj.put("id",res.getId());
			obj.put("dob",res.getDob());
			obj.put("addressId",res.getAddressId());
			obj.put("email",res.getEmail());
			obj.put("loginId",res.getLoginId());
		return obj;
	}
	public void getDataFromPort2() {
		try {
			URL urlPassenger = new URL("http://www.kiruthicrailwayreservation.com:8081/PassengerServlet?query=allPassenger");
			URLConnection yc = urlPassenger.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
			String inputLine;
			JSONParser parser = new JSONParser();
			ArrayList<Passenger> arr = new ArrayList<>();
            while ((inputLine = in.readLine()) != null) {     
                JSONArray a = (JSONArray) parser.parse(inputLine);
                for (Object o : a) {
                    JSONObject obj = (JSONObject) o;
					Long l1 = new Long((Long)obj.get("id"));
					Long l2 = new Long((Long)obj.get("addressId"));
					Long l3 = new Long((Long)obj.get("loginId"));
					p = new Passenger((String)obj.get("name"),(String)obj.get("dob"),l2.intValue(),(String)obj.get("email"));
					p.setId(l1.intValue());
					p.setLoginId(l3.intValue());
					arr.add(p);
                }
            }
			URL urlAddress = new URL("http://www.kiruthicrailwayreservation.com:8081/PassengerServlet?query=allAddress");
			URLConnection yc1 = urlAddress.openConnection();
			BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
			String inputLine1;
			JSONParser parser1 = new JSONParser();
			ArrayList<Address> arrAdd = new ArrayList<>();
            while ((inputLine1 = in1.readLine()) != null) {     
                JSONArray addObj = (JSONArray) parser1.parse(inputLine1);
                for (Object o : addObj) {
                    JSONObject obj = (JSONObject) o;
					Long l1 = new Long((Long)obj.get("id"));
					Long l2 = new Long((Long)obj.get("postalCode"));
					Address a = new Address((String)obj.get("street"),(String)obj.get("city"),l2.intValue());
					a.setId(l1.intValue());
					arrAdd.add(a);
             
                }
            }
			URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:8081/PassengerServlet?query=allLogin");
			URLConnection yc2 = urlLogin.openConnection();
			BufferedReader in2 = new BufferedReader(new InputStreamReader(yc2.getInputStream()));
			String inputLine2;
			JSONParser parser2 = new JSONParser();
			ArrayList<Login> arrLog = new ArrayList<>();
            while ((inputLine2 = in2.readLine()) != null) {     
                JSONArray addObj = (JSONArray) parser2.parse(inputLine2);
                for (Object o : addObj) {
                    JSONObject obj = (JSONObject) o;
					Long l1 = new Long((Long)obj.get("id"));
					Login log = new Login((String)obj.get("email"),(String)obj.get("password"));
					log.setId(l1.intValue());
					arrLog.add(log);
             
                }
            }
			URL urlPassengerPort2 = new URL("http://www.kiruthicrailwayreservation.com:9999/PassengerServlet?query=allPassenger");
			URLConnection ycPort2 = urlPassengerPort2.openConnection();
			BufferedReader inPort2 = new BufferedReader(new InputStreamReader(ycPort2.getInputStream()));
			while ((inputLine = inPort2.readLine()) != null) {     
                JSONArray a = (JSONArray) parser.parse(inputLine);
                for (Object o : a) {
                    JSONObject obj = (JSONObject) o;
					Long l1 = new Long((Long)obj.get("id"));
					Long l2 = new Long((Long)obj.get("addressId"));
					Long l3 = new Long((Long)obj.get("loginId"));
					p = new Passenger((String)obj.get("name"),(String)obj.get("dob"),l2.intValue(),(String)obj.get("email"));
					p.setId(l1.intValue());
					p.setLoginId(l3.intValue());
					arr.add(p);
                    
                }
            }
			URL urlAddressPort2 = new URL("http://www.kiruthicrailwayreservation.com:9999/PassengerServlet?query=allAddress");
			URLConnection yc1Port2 = urlAddressPort2.openConnection();
			BufferedReader in1Port2 = new BufferedReader(new InputStreamReader(yc1Port2.getInputStream()));
			while ((inputLine1 = in1Port2.readLine()) != null) {     
                JSONArray addObj = (JSONArray) parser1.parse(inputLine1);
                for (Object o : addObj) {
                    JSONObject obj = (JSONObject) o;
					Long l1 = new Long((Long)obj.get("id"));
					Long l2 = new Long((Long)obj.get("postalCode"));
					Address a = new Address((String)obj.get("street"),(String)obj.get("city"),l2.intValue());
					a.setId(l1.intValue());
					arrAdd.add(a);
             
                }
            }
			URL urlLoginPort2 = new URL("http://www.kiruthicrailwayreservation.com:9999/PassengerServlet?query=allLogin");
			URLConnection yc2Port2 = urlLoginPort2.openConnection();
			BufferedReader in2Port2 = new BufferedReader(new InputStreamReader(yc2Port2.getInputStream()));
			while ((inputLine2 = in2Port2.readLine()) != null) {     
                JSONArray addObj = (JSONArray) parser2.parse(inputLine2);
                for (Object o : addObj) {
                    JSONObject obj = (JSONObject) o;
					Long l1 = new Long((Long)obj.get("id"));
					Login log = new Login((String)obj.get("email"),(String)obj.get("password"));
					log.setId(l1.intValue());
					arrLog.add(log);
             
                }
            }
			passengerService.updateOrCheckPassenger(con,arr,arrAdd, arrLog);
			System.out.println(arr);
            in.close();
		} catch (Exception e) {
				throw new IllegalStateException(e);
		}
		
		
	}*/
}
