
public class Train {

	private String trainName;
	private int trainNumber;
	private int noOfSeats;
	private String routeAreas;

	public Train(String trainName, int trainNumber, int noOfSeats, String routeAreas) {
		this.trainName = trainName;
		this.trainNumber = trainNumber;
		this.noOfSeats = noOfSeats;
		this.routeAreas = routeAreas;

	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public int getTrainNumber() {
		return trainNumber;
	}

	public void setTrainNumber(int trainNumber) {
		this.trainNumber = trainNumber;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public String getRouteAreas() {
		return routeAreas;
	}

	public void setRouteAreas(String routeAreas) {
		this.routeAreas = routeAreas;
	}
}