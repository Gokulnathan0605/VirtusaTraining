import java.util.*;
import java.sql.*;
import java.net.*;   

public class PortTransferService {
	private String sql;
	private PreparedStatement ps; 
	
	
	public  boolean hostAvailabilityCheck(String SERVER_ADDRESS,int TCP_SERVER_PORT ) { 
		try (Socket s = new Socket(SERVER_ADDRESS, TCP_SERVER_PORT)) {
			return true;
		} catch (Exception ex) {
		}
		return false;
	}
	
	public void addPortUpdate(Connection con, String arg, String objName, int portNo) throws Exception{
		sql = "INSERT INTO portTransferData(operation, portNo, parameters) VALUES(?,?,?)";
		ps = con.prepareStatement(sql);
		ps.setString(1, objName);
		ps.setInt(2, portNo);
		ps.setString(3, arg);
		int rows = ps.executeUpdate();
	}
	public boolean getPortUpdateNo(Connection con, String arg) throws Exception {
		sql = "SELECT * FROM portTransferData WHERE parameters=?";
		ps=con.prepareStatement(sql);
		ps.setString(1, arg);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			if(rs.getInt("id") > 0) {
				return true;
			}
		}
		return false;
	}
	
	public int checkPortUpdate(Connection con, String objName, int portNo) throws Exception{
		sql = "SELECT * FROM portTransferData WHERE operation=? AND portNo=?";
		int count=0;
		ps=con.prepareStatement(sql);
		ps.setString(1, objName);
		ps.setInt(2, portNo);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			count++;
		}
		return count;
	}
	
	public ResultSet getPortUpdate(Connection con, String objName, int portNo) throws Exception{
		sql = "SELECT * FROM portTransferData WHERE operation=? AND portNo=?";
		ps=con.prepareStatement(sql);
		ps.setString(1, objName);
		ps.setInt(2, portNo);
		ResultSet rs = ps.executeQuery();
		
		return rs;
	}
	
	public void deletePortUpdate(Connection con, int id) throws Exception{
		sql = "DELETE FROM portTransferData WHERE id=?";
		ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		
		ps.executeUpdate();
	}
}