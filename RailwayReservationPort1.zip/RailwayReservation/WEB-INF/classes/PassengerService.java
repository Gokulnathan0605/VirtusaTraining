
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;

import java.util.*;
import java.io.*;


//PSQL - port1



public class PassengerService {
	static String sql;
	static PreparedStatement st;
	static Passenger p;
	private AddressService as = new AddressService();
	public int createLogin(Connection con, String email, String password) {
		try {
			int lid = -1;
			lid = checkLogin(con, email);
			if(lid > 0) {
				lid = updateLogin(con, new Login(email, password));
				return lid;
			}
			String sql = "INSERT INTO logindetail(email, password) VALUES(?, ?);";
			st = con.prepareStatement(sql);
			st.setString(1, email);
			st.setString(2, password);
			
			int rowsInserted = st.executeUpdate();

			if (rowsInserted > 0) {
				lid = checkLogin(con, email);
			}
			return lid;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	public void createHoldLogin(Connection con, ArrayList<Login> arr) {
		for(Login l : arr) {
			createLogin(con, l.getEmail(), l.getPassword());
		}
	}
	
	public void createHoldPassenger(Connection con,ArrayList<Passenger> arr ) {
		for(Passenger p : arr) {
			createPassenger(p, p.getAddress(), p.getLoginId(), con);
		}
	}
	public Login readLogin(Connection con, String email) {
		try {
			String sql = "SELECT * FROM logindetail WHERE email=?";
			st = con.prepareStatement(sql);
			st.setString(1,email);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				Login login = new Login(rs.getString("email"), rs.getString("password"));
				login.setId(rs.getInt("id"));
				return login;
			}
			return null;
		}catch (Exception e) {
			throw new IllegalStateException(e);
		}
	
	}
	
	public void updateParticularDetails(Connection con, HashMap<String, String> map) throws Exception{
		String sql = "UPDATE passengerdetail SET ";
		Passenger pas = passengerByEmail(con, map.get("email"));
		Address a = as.readAddress(pas.getAddressId(), con);
		String street = a.getStreet();
		String city = a.getCity();
		int pos = a.getPostalCode();
		for(Map.Entry<String, String> entry : map.entrySet()) {
			switch(entry.getKey()) {
				case "pasName":
					sql += "passengerName" + "=?, ";
					break;
				case "pasDob":
					sql += "dateOfBirth" + "=?, ";
					break;
				case "addStreet":
					a.setStreet(entry.getValue());
					break;
				case "addCity":
					a.setStreet(entry.getValue());
					break;
				case "addPostalCode":
					a.setPostalCode(Integer.parseInt(entry.getValue()));
					break;
				
			}
			
		}
		if(!street.equals(a.getStreet()) || !city.equals(a.getCity()) || a.getPostalCode() != pos) {
		int addressId = as.updateAddress(a, con);
			sql += "addressId=" + addressId;
		}
		if(!sql.contains("addressId")) {
			sql = sql.substring(0,sql.length()-2);
		}
		sql += " WHERE id=?";
		System.out.println("SQL: " + sql);
		st = con.prepareStatement(sql);
		int i = 1;
		for(Map.Entry<String, String> entry : map.entrySet()) {
			switch(entry.getKey()) {
				case "pasName":
					st.setString(i, entry.getValue());
					i++;
					break;
				case "pasDob":
					st.setString(i, entry.getValue());
					i++;
					break;
				
			}
		}
		st.setInt(i, pas.getId());
		st.executeUpdate();
	}
	
	public int checkLogin(Connection con, String email) {
		try {
			
			String sql = "SELECT * FROM logindetail WHERE email=?";
			st = con.prepareStatement(sql);
			st.setString(1, email);
			
			
			ResultSet rs = st.executeQuery();

			if (rs.next()) {
				return rs.getInt("id");
			}
			return -1;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	public boolean createPassenger(Passenger passenger, Address address, int loginId, Connection con) {

		try {
			if(checkPassenger(con, passenger.getEmail()) > 0) {
				updatePassenger(passenger, address, con, loginId);
				return true;
			}
			passenger.setAddressId(as.createAddress(address, con));
			String sql = "INSERT INTO passengerdetail(passengerName,  addressId, email, loginId, dateOfBirth) VALUES(?, ?, ?, ?, ?);";
			st = con.prepareStatement(sql);
			st.setString(1, passenger.getName());
			st.setString(5, passenger.getDob());
			st.setInt(2, passenger.getAddressId());
			st.setString(3, passenger.getEmail());
			st.setInt(4, loginId);
			int rowsInserted = st.executeUpdate();

			if (rowsInserted > 0) {
				return true;
			}
			return false;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public int updateLogin(Connection con, Login l) throws Exception {
		String sql = "UPDATE logindetail SET password=? WHERE email=?";
		st = con.prepareStatement(sql);
		st.setString(2,l.getEmail());
		st.setString(1,l.getPassword());
		int rows = st.executeUpdate();
		return rows;
		
	}
	/*public void updateOrCheckPassenger(Connection con, ArrayList<Passenger> arr, ArrayList<Address> arrAdd, ArrayList<Login> arrLog) throws Exception{
		int id = -1;
		for(Login l : arrLog) {
			id = checkLogin(con, l.getEmail());
			if(id <= 0) {
				id = createLogin(con, l.getEmail(), l.getPassword());
			} 				
		}
		for(Passenger p : arr) {
			for(Address a : arrAdd) {
				if(p.getAddressId() == a.getId()) {
					id = checkLogin(con, p.getEmail());
					if(!updatePassenger(p,a,con,id)) {
						createPassenger(p,a,id,con);
					}
				}
			}
		}
		
	}*/
	public int checkPassenger(Connection con, String email) {
		try {
			String sql = "SELECT  * FROM passengerdetail WHERE email=? ";
			st = con.prepareStatement(sql);
			st.setString(1, email);
			ResultSet rs = st.executeQuery();
			
			if(rs.next()) {
				System.out.println("passenger Id: " + rs.getInt("id"));
				return rs.getInt("id");
			}
			return 0;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

//	public static boolean checkRightPassenger(Connection con, String email) {
//		try {
//			String sql = "SELECT * FROM passengerdetail WHERE email=?";
//			st = con.prepareStatement(sql);
//			st.setString(1,email);
//			ResultSet rs = st.executeQuery();
//			if(rs.next()) {
//				
//			}
//		}catch(Exception e) {
//			throw new IllegalStateException(e);
//		}
//	}

	public Passenger passengerByEmail(Connection con, String email) {
		try {
			String sql = "SELECT  * FROM passengerdetail WHERE email=? ";
			st = con.prepareStatement(sql);
			st.setString(1, email);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				p = new Passenger(rs.getString("passengerName"), rs.getString("dateOfBirth"),
						rs.getInt("addressId"), rs.getString("email"));
				p.setId(rs.getInt("id"));
			}
			return p;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public Passenger getPassenger(Connection con, int loginId) {
		try {
			sql = "SELECT * FROM passengerdetail WHERE loginId=?";
			st = con.prepareStatement(sql);
			st.setInt(1, loginId);
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				return new Passenger(rs.getString("passengerName"), rs.getString("dateOfBirth"),rs.getInt("addressId"), rs.getString("email"));
			}
			return null;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public boolean updatePassenger(Passenger passenger, Address address, Connection con, int loginId) {
		try {
			sql = "UPDATE passengerdetail SET passengerName=?, dateOfBirth=?, addressId=? WHERE loginId=?";
			st = con.prepareStatement(sql);
			passenger.setAddressId(as.updateAddress(address,con));
			st.setString(1, passenger.getName());
			st.setString(2, passenger.getDob());
			st.setInt(3, passenger.getAddressId());
			st.setInt(4, loginId);
			int rowAffected = st.executeUpdate();
			if (rowAffected > 0) {
				return true;
			}
			return false;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	public ResultSet readAllPassenger(Connection con) {
		try {
			sql = "SELECT * FROM passengerdetail ";
			st = con.prepareStatement(sql);

			ResultSet rs = st.executeQuery();
			
			return rs;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	public ResultSet readAllLogin(Connection con) {
		try {
			sql = "SELECT * FROM logindetail ";
			st = con.prepareStatement(sql);

			ResultSet rs = st.executeQuery();
			
			return rs;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	/*public void setPSQLLogin(Connection con, ArrayList<ArrayList<String>> loginArray ) {
		try {
			sql = "TRUNCATE TABLE logindetail; ";
			st = con.prepareStatement(sql);
			st.execute(sql);
			for(ArrayList<String> arr : loginArray) {
				String sql1 = "INSERT INTO logindetail(email, password) VALUES(?, ?)";
				st = con.prepareStatement(sql1);
				st.setString(1, arr.get(0));
				st.setString(2, arr.get(1));
				st.executeUpdate();
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public void importLoginCsv(Connection con) {
		BufferedReader reader = null;
		ArrayList<ArrayList<String>> loginArray = new ArrayList<>();
		try {
			String line = "";
			reader = new BufferedReader(new FileReader("C://Program Files//Apache Software Foundation//CSV//PSQL//logindetail.csv"));
			reader.readLine();
			while((line = reader.readLine()) != null) {
				String[] fields = line.split(",");
				ArrayList<String> inner = new ArrayList<>();
				if(fields.length > 0) {
					String username = fields[1];
					String password = fields[2];
					inner.add(username);
					inner.add(password);
					loginArray.add(inner);
				}
			}
			setPSQLLogin(con, loginArray);
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public void exportLoginCsv(Connection con) {
		ResultSet rs = readAllLogin(con);
		FileWriter fw = null;
		try {
			fw = new FileWriter("C://Program Files//Apache Software Foundation//CSV//MYSQL//logindetail.csv");
			fw.append("id, email, password");
			fw.append("\n");
			while(rs.next()) {
				fw.append(String.valueOf(rs.getInt("id")));
				fw.append(",");
				fw.append(rs.getString("email"));
				fw.append(",");
				fw.append(rs.getString("password"));
				
				fw.append("\n");
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			try {
				fw.flush();
				fw.close();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			
			}
		}
		System.out.println(" Login Data Entered");
	}
	
	public void setPSQLPassenger(Connection con, ArrayList<Passenger> pList) {
		try {
			sql = "TRUNCATE TABLE passengerdetail;";
			st = con.prepareStatement(sql);
			st.execute(sql);
			for(Passenger passenger : pList) {
				sql = "INSERT INTO passengerdetail(passengerName,  addressId, email, loginId, dateOfBirth) VALUES(?, ?, ?, ?, ?);";
				st = con.prepareStatement(sql);
				st.setString(1, passenger.getName());
				st.setString(5, passenger.getDob());
				st.setInt(2, passenger.getAddressId());
				st.setString(3, passenger.getEmail());
				st.setInt(4, passenger.getLoginId());
				st.executeUpdate();
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public void importPassengerCsv(Connection con) {
		BufferedReader reader = null;
		try {
			ArrayList<Passenger> pList = new ArrayList<>();
			String line = "";
			reader = new BufferedReader(new FileReader("C://Program Files//Apache Software Foundation//CSV//PSQL//passengerdetail.csv"));
			reader.readLine();
			while((line = reader.readLine()) != null) {
				String[] fields = line.split(",");
				
				if(fields.length > 0) {
					//p = new Passenger()
					p.setName(fields[1]);
					p.setAddressId(Integer.parseInt(fields[2]));
					p.setEmail(fields[3]);
					p.setDob(fields[4]);
					p.setLoginId(Integer.parseInt(fields[5]));
					pList.add(p);
				}
			}
			setPSQLPassenger(con, pList);
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public void exportPassengerCsv(Connection con) {
		ResultSet rs = readAllPassenger(con);
		FileWriter fw = null;
		try {
			fw = new FileWriter("C://Program Files//Apache Software Foundation//CSV//MYSQL//passengerdetail.csv");
			fw.append("id, passengerName, addressId, email, dateOfBirth, loginId");
			fw.append("\n");
			while(rs.next()) {
				fw.append(String.valueOf(rs.getInt("id")));
				fw.append(",");
				fw.append(rs.getString("passengerName"));
				fw.append(",");
				fw.append(String.valueOf(rs.getInt("addressId")));
				fw.append(",");
				fw.append(rs.getString("email"));
				fw.append(",");
				fw.append(rs.getString("dateOfBirth"));
				fw.append(",");
				fw.append(String.valueOf(rs.getInt("loginId")));
				fw.append("\n");
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			try {
				fw.flush();
				fw.close();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			
			}
		}
		System.out.println(" Passenger Data Entered");
	}*/
	/*public Passenger checkNewPassenger(Passenger passenger, Connection con) {
		try {
			sql = "SELECT * FROM passengerdetail WHERE email = ?";
			st = con.prepareStatement(sql);
			st.setString(1, passenger.getEmail());
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				p = new Passenger(rs.getString("passengerName"), rs.getInt("age"),
						rs.getInt("addressId"), rs.getString("email"));
				p.setId(rs.getInt("id"));
			}
			return p;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}*/
}