 
import java.net.*;
import java.util.*;
import java.sql.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 
@Path("passengerResource")
//@Produces(MediaType.ALL)
public class PassengerResource {
    private PassengerService ps = new PassengerService();
     
    // RESTful API methods go here...  
	@Path("allPassenger")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Passenger> list() throws Exception{
		ResultSet rs = ps.readAllPassenger(MysqlConnection.getConnection());
		List<Passenger> l = new ArrayList<>();
		while(rs.next()) {
			Passenger p = new Passenger(rs.getString("name"), rs.getString("dateOfBirth"), rs.getInt("addressId"), rs.getString("email"));
			p.setId(rs.getInt("id"));
			p.setLoginId(rs.getInt("loginId"));
			l.add(p);
		}
		System.out.println("Successfully fetched data");
		return l;
	}
     
}