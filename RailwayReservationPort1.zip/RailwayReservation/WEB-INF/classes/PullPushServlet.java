import javax.servlet.*;
import java.util.*;
import org.json.simple.parser.*;
import java.sql.*;
import org.json.simple.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.lang.Thread;
import javafx.application.*;
import javafx.util.Duration;
import javafx.animation.*;
public class PullPushServlet implements ServletContextListener, Runnable{
	
	private BookingService bs = new BookingService();
	private PortTransferService pts = new PortTransferService();
	private Connection con = MysqlConnection.getConnection();
	private Address ad;
	private Passenger p;
	private AddressService as = new AddressService();
	private PassengerService ps = new PassengerService();
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		System.out.println("ServletContextListener destroyed");
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("ServletContextListener started");
		SyncDatabaseTable sdt = new SyncDatabaseTable();
		try {
		sdt.readXMLFile();
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
		PullPushServlet pps = new PullPushServlet();
		ServletContext sc = sce.getServletContext();
		System.out.println("Servlet Context : " + sc);
		Thread t = new Thread(pps);
		t.start();
	}
	public void run() {
			pullLoginDetail();
					pullPassengerDetail();
					pullBookingDetail();
					pullCancelDetail();
		}
	
	public void pullLoginDetail() {
		
		String nameofCurrMethod = new Throwable()
                                      .getStackTrace()[0]
                                      .getMethodName();
  
        System.out.println("Name of current method: "
            + nameofCurrMethod);
		String inputLine;
		JSONParser parser = new JSONParser();
		ArrayList<Login> arrLog = new ArrayList<>();
		try {
			if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
				System.out.println("Welcome to 9999");
				URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/LoginServlet?port=8080&query=allHoldLogin");
				URLConnection yc = urlLogin.openConnection();
				BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
				System.out.println("Port 9999");
				while ((inputLine = in.readLine()) != null) {     
					JSONArray addObj = (JSONArray) parser.parse(inputLine);
					for (Object o : addObj) {
						JSONObject obj = (JSONObject) o;
						Long l1 = new Long((Long)obj.get("id"));
						Login log = new Login((String)obj.get("email"),(String)obj.get("password"));
						log.setId(l1.intValue());
						arrLog.add(log);
				 
					}
				}
			}
			System.out.println("not Port 9999");
			if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
				URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/LoginServlet?port=8080&query=allHoldLogin");
				URLConnection yc1 = urlLogin1.openConnection();
				BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
				System.out.println(" Port 8081");
				while ((inputLine = in1.readLine()) != null) {     
					JSONArray addObj = (JSONArray) parser.parse(inputLine);
					for (Object o : addObj) {
						JSONObject obj = (JSONObject) o;
						Long l1 = new Long((Long)obj.get("id"));
						Login log = new Login((String)obj.get("email"),(String)obj.get("password"));
						log.setId(l1.intValue());
						arrLog.add(log);
				 
					}
				}
			}
			System.out.println("not Port 8081");
			ps.createHoldLogin(con, arrLog);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
		
	}
	
	public void pullPassengerDetail() {
		
		String nameofCurrMethod = new Throwable()
                                      .getStackTrace()[0]
                                      .getMethodName();
  
        System.out.println("Name of current method: "
            + nameofCurrMethod);
		String inputLine;
		JSONParser parser = new JSONParser();
		ArrayList<Passenger> arr = new ArrayList<>();
		try {
			if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
				URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/PassengerServlet?port=8080&query=allHoldPassenger");
				URLConnection yc = urlLogin.openConnection();
				BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
				
				while ((inputLine = in.readLine()) != null) {     
					JSONArray a = (JSONArray) parser.parse(inputLine);
					for (Object o : a) {
						JSONObject obj = (JSONObject) o;
						
						Long l1 = new Long((Long)obj.get("id"));
						Long l3 = new Long((Long)obj.get("loginId"));
						Long pos = new Long((Long)obj.get("postalCode"));
						ad = new Address((String)obj.get("street"), (String)obj.get("city"), pos.intValue());
						int adId = as.createAddress(ad,con);
						ad.setId(adId);
						p = new Passenger((String)obj.get("name"),(String)obj.get("dob"),adId,(String)obj.get("email"));
						p.setId(l1.intValue());
						p.setLoginId(l3.intValue());
						p.setAddress(ad);
						arr.add(p);
						
					}
				}
			}
			if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
				URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/PassengerServlet?port=8080&query=allHoldPassenger");
				URLConnection yc1 = urlLogin1.openConnection();
				BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
				while ((inputLine = in1.readLine()) != null) {     
					JSONArray a = (JSONArray) parser.parse(inputLine);
					for (Object o : a) {
						JSONObject obj = (JSONObject) o;
						
						Long l1 = new Long((Long)obj.get("id"));
						Long l3 = new Long((Long)obj.get("loginId"));
						Long pos = new Long((Long)obj.get("postalCode"));
						ad = new Address((String)obj.get("street"), (String)obj.get("city"), pos.intValue());
						int adId = as.createAddress(ad,con);
						ad.setId(adId);
						p = new Passenger((String)obj.get("name"),(String)obj.get("dob"),adId,(String)obj.get("email"));
						p.setId(l1.intValue());
						p.setLoginId(l3.intValue());
						p.setAddress(ad);
						arr.add(p);
						
					}
				}
			}
			ps.createHoldPassenger(con, arr);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
		
	}
	
	public void pullBookingDetail() {
		
		String nameofCurrMethod = new Throwable()
                                      .getStackTrace()[0]
                                      .getMethodName();
  
        System.out.println("Name of current method: "
            + nameofCurrMethod);
		String inputLine;
		JSONParser parser = new JSONParser();
		ArrayList<BookingDetail> arr = new ArrayList<>();
		try {
			if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
				System.out.println("Welcome to 9999");
				URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/BookingServlet?port=8080&query=allHoldBooking");
				URLConnection yc = urlLogin.openConnection();
				BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));

				while ((inputLine = in.readLine()) != null) {
					JSONArray addObj = (JSONArray) parser.parse(inputLine);
					for (Object o : addObj) {
						JSONObject obj = (JSONObject) o;
						Long l1 = new Long((Long)obj.get("id"));
						Long trainId = new Long((Long)obj.get("trainId"));
						Long logId = new Long((Long)obj.get("loginId"));
						Long noOfSeats = new Long((Long)obj.get("noOfSeats"));
							BookingDetail b = new BookingDetail(trainId.intValue(),logId.intValue(), noOfSeats.intValue(),
							(String)obj.get("boardingDate"), (String)obj.get("startingPoint"),(String)obj.get("endingPoint"));

						arr.add(b);

					}
				}
			}
			if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
				URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/BookingServlet?port=8080&query=allHoldBooking");
				URLConnection yc1 = urlLogin1.openConnection();
				BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
				while ((inputLine = in1.readLine()) != null) {
					JSONArray addObj = (JSONArray) parser.parse(inputLine);
					for (Object o : addObj) {
						JSONObject obj = (JSONObject) o;
						Long l1 = new Long((Long)obj.get("id"));
						Long trainId = new Long((Long)obj.get("trainId"));
						Long logId = new Long((Long)obj.get("loginId"));
						Long noOfSeats = new Long((Long)obj.get("noOfSeats"));
							BookingDetail b = new BookingDetail(trainId.intValue(),logId.intValue(), noOfSeats.intValue(),
							(String)obj.get("boardingDate"), (String)obj.get("startingPoint"),(String)obj.get("endingPoint"));

						arr.add(b);

					}
				}
			}
			bs.createHoldBooking(con, arr);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
		
	}
	
	public void pullCancelDetail() {
		
		String nameofCurrMethod = new Throwable()
                                      .getStackTrace()[0]
                                      .getMethodName();
  
        System.out.println("Name of current method: "
            + nameofCurrMethod);
		String inputLine;
		JSONParser parser = new JSONParser();
		ArrayList<String> arr = new ArrayList<>();
		try {
			if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
				System.out.println("Welcome to 9999");
				URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/CancelServlet?port=8080&query=allHoldCancel");
				URLConnection yc = urlLogin.openConnection();
				BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
				
				while ((inputLine = in.readLine()) != null) {     
					JSONArray addObj = (JSONArray) parser.parse(inputLine);
					for (Object o : addObj) {
						JSONObject obj = (JSONObject) o;
						
						arr.add((String)obj.get("pnr"));
				 
					}
				}
			}
			if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
				URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/CancelServlet?port=8080&query=allHoldCancel");
				URLConnection yc1 = urlLogin1.openConnection();
				BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
				while ((inputLine = in1.readLine()) != null) {     
					JSONArray addObj = (JSONArray) parser.parse(inputLine);
					for (Object o : addObj) {
						JSONObject obj = (JSONObject) o;
						
						arr.add((String)obj.get("pnr"));
				 
					}
				}
			}
			bs.createHoldCancel(con, arr);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
		
	}
	
}