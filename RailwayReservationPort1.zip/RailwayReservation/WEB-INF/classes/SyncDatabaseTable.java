import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import java.net.*;
public class SyncDatabaseTable {
	
	private HashMap<String, Object> map = new HashMap<>();
	private HashMap<String, Object> tableMap = new HashMap<>();
	private HashMap<String, Object> columnMap = new HashMap<>();
	private HashMap<String, Object> fieldMap = new HashMap<>();
	private PassengerService ps = new PassengerService();
	private AddressService as = new AddressService();
	private BookingService bs = new BookingService();
	private TrainService ts = new TrainService();
	private PortTransferService pts = new PortTransferService();
	
	public void readXMLFile() throws Exception{
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		Document document = docBuilder.parse(new File("C:\\Program Files\\Apache Software Foundation\\Port3\\webapps\\RailwayReservation\\WEB-INF\\conf\\tables.xml"));
		Node node = document.getDocumentElement();
		if(node.getNodeName().equals("root")) {
			System.out.println(node.getNodeName());
			NodeList tableNodeList = node.getChildNodes();
			for(int i = 0; i < tableNodeList.getLength(); i++) {
				Node tableNode = tableNodeList.item(i);
				columnMap = new HashMap<>();
				if(tableNode.getNodeName().equals("table")) {
					NodeList columnNodeList = tableNode.getChildNodes();
					for(int j = 0; j < columnNodeList.getLength(); j++) {
						Node columnNode = columnNodeList.item(j);
						if(columnNode.getNodeName().equals("column")) {
							fieldMap = new HashMap<>();
							int size= columnNode.getAttributes().getLength();
							String field = "";
							for(int k = 0; k < size; k++) {
								if(!columnNode.getAttributes().item(k).getNodeName().equals("name")) {
									field += columnNode.getAttributes().item(k).getNodeName()+","+columnNode.getAttributes().item(k).getNodeValue()+";";
								}
							}
							if(field.contains("length")) {
								int index = field.indexOf("length,");
								int last = field.lastIndexOf(";type,");
								String alter = field.substring(index, last + 1);
								field = field.substring(0, index) + field.substring(last + 1, field.length()) + alter;
							}
								field = field.substring(0, field.length() - 1);
							columnMap.put("column"+j,field);
						}
					
					}
					tableMap.put("table Name:"+tableNode.getAttributes().getNamedItem("alias").getNodeValue(),columnMap);
				}
			}
		}
		updateDatabase();
	}
	public void updateDatabase() throws Exception{
	//	System.out.println(tableMap);
		for(Map.Entry<String, Object> table : tableMap.entrySet()) {
			HashMap<String, Object> attributes = new HashMap<>();
			String tableName = table.getKey();
			String[] array = tableName.split(":");
			System.out.println(array[1]);
			Connection con = MysqlConnection.getConnection();
			String sql = "CREATE TABLE IF NOT EXISTS " +array[1]+"(";
			
			String field = "";
			map=(HashMap<String, Object>)table.getValue();
			for(Map.Entry<String, Object> column : map.entrySet()) {
				field = (String)column.getValue();
				
			
				String[] arr = field.split(";");
				
				for(String i : arr) {
					String[] str = i.split(",");
					boolean condition = false;
					switch(str[0]) {
						case "alias":
							if(str[1].equals("id")) {
								sql += str[1] + " SERIAL ";
							} else {
								sql += str[1] + " ";
							}
							break;
						case "type":
							if(str[1].equals("int")){
								sql += "INT ";
							} else if(str[1].equals("String")) {
								sql += "CHAR ";
							} else if(str[1].equals("float")){
								sql += "FLOAT ";
							} else {
								sql += str[1] + " ";
							}
							break;
						case "length":
							sql += "("+str[1]+")";
							break;
					}
				}
				sql += ",";
			}
			sql = sql.substring(0, sql.length() - 1);
			sql += ")";
			System.out.println(sql);
			Statement ps = con.createStatement();
			ps.executeUpdate(sql);
		}
	}
	
	
}