import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.sql.*;

import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import org.json.simple.parser.*;

import org.json.simple.*;



/**
 * Servlet implementation class CancelServlet
 */
@WebServlet("/CancelServlet")
public class CancelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookingService bs = new BookingService();
	private TrainService ts = new TrainService();
	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private InputStream is;
	private Connection con = MysqlConnection.getConnection();
	private Queue<BookingDetail> queue = new LinkedList<>();
	private boolean cancelCon = false;;
	private PortTransferService pts = new PortTransferService();

	public CancelServlet() {
		super();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				if(request.getQueryString() != null) {
			String json="";
			try {
				if(request.getParameter("query").equals("allHoldCancel")) {
					int port = Integer.parseInt(request.getParameter("port"));
					ResultSet rs = pts.getPortUpdate(con, "Cancel", port);
					JSONArray arr = new JSONArray();
					while(rs.next()) {
						String arguments = rs.getString("parameters");
						
						JSONObject obj = new JSONObject();
						obj.put("pnr", arguments);
						obj.put("id", rs.getInt("id"));	
						arr.add(obj);
						pts.deletePortUpdate(con, rs.getInt("id"));
					}
					
					json = arr.toString();
				}
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				out.print(json);
				out.flush();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
		} else {
			String inputLine;
			JSONParser parser = new JSONParser();
			ArrayList<String> arr = new ArrayList<>();
			try {
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					System.out.println("Welcome to 9999");
					URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/CancelServlet?port=8080&query=allHoldCancel");
					URLConnection yc = urlLogin.openConnection();
					BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
					
					while ((inputLine = in.readLine()) != null) {     
						JSONArray addObj = (JSONArray) parser.parse(inputLine);
						for (Object o : addObj) {
							JSONObject obj = (JSONObject) o;
							
							arr.add((String)obj.get("pnr"));
					 
						}
					}
				}
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/CancelServlet?port=8080&query=allHoldCancel");
					URLConnection yc1 = urlLogin1.openConnection();
					BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
					while ((inputLine = in1.readLine()) != null) {     
						JSONArray addObj = (JSONArray) parser.parse(inputLine);
						for (Object o : addObj) {
							JSONObject obj = (JSONObject) o;
							
							arr.add((String)obj.get("pnr"));
					 
						}
					}
				}
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			bs.createHoldCancel(con, arr);
			RequestDispatcher dispatcher = request.getRequestDispatcher("CancelPage.jsp");
			dispatcher.forward(request, response);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		if(request.getQueryString() != null) {
			String query = request.getParameter("query");
			String pnr = "";
			if(query.equals("updateCancel")) {
				pnr = request.getParameter("cancelPnr");
			}
			cancelTicket(pnr);
		} else {
	
			String pnr = request.getParameter("pnr");
			System.out.println(pnr);
			cancelTicket(pnr);
			
			try { 

				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					String u1 = "http://www.kiruthicrailwayReservation.com:8081/CancelServlet?query=updateCancel&cancelPnr="+pnr;
					

					pts.addPortUpdate(con, pnr, "Cancel", 8081);
					URLConnection url1 = new URL(u1).openConnection();
					HttpURLConnection http1 = (HttpURLConnection)url1;
					http1.setRequestMethod("POST");
					http1.setDoOutput(true);
					try {
						int count = 0;
						while((count = pts.checkPortUpdate(con, "Cancel",8081)) != 0) {
							ResultSet rs = pts.getPortUpdate(con, "Cancel", 8081);
							String arguments="";
							if(rs.next()) {
								arguments = rs.getString("parameters");
							}
							pts.deletePortUpdate(con, rs.getInt("id"));
							Map<String, String> arg = new HashMap<>();
							arg.put("pnr",arguments);
							StringJoiner sj = new StringJoiner("&");
							for(Map.Entry<String, String> entry : arg.entrySet()) {
								sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
										+ URLEncoder.encode(entry.getValue(), "UTF-8"));
							}
							byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
							int length = out.length;
							
							http1.setFixedLengthStreamingMode(length);
							http1.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
							http1.connect();
							try(OutputStream os = http1.getOutputStream()) {
								os.write(out);
							} catch (Exception e) {
								throw new IllegalStateException(e);
							}
						}
						
					}catch (Exception e) {
								throw new IllegalStateException(e);
					}
					http1.disconnect();
				} else {
					String arguments = pnr;
					pts.addPortUpdate(con, arguments, "Cancel", 8081);
					
				}
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					String u2 = "http://www.kiruthicrailwayReservation.com:9999/CancelServlet?query=updateCancel&cancelPnr="+pnr;
					
					pts.addPortUpdate(con, pnr, "Cancel", 9999);

					URLConnection url2 = new URL(u2).openConnection();
					HttpURLConnection http2 = (HttpURLConnection)url2;
					
					http2.setRequestMethod("POST");
					
					http2.setDoOutput(true);
					try {
						int count = 0;
						while((count = pts.checkPortUpdate(con, "Cancel",9999)) != 0) {
							ResultSet rs = pts.getPortUpdate(con, "Cancel", 9999);
							String arguments="";
							if(rs.next()) {
								arguments = rs.getString("parameters");
							}
							pts.deletePortUpdate(con, rs.getInt("id"));
							Map<String, String> arg = new HashMap<>();
							arg.put("pnr",arguments);
							StringJoiner sj = new StringJoiner("&");
							for(Map.Entry<String, String> entry : arg.entrySet()) {
								sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
										+ URLEncoder.encode(entry.getValue(), "UTF-8"));
							}
							byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
							int length = out.length;
							
							http2.setFixedLengthStreamingMode(length);
					
							http2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
							
							http2.connect();
							try(OutputStream os = http2.getOutputStream()) {
								os.write(out);
							} catch (Exception e) {
								throw new IllegalStateException(e);
							}
							
						}
					}catch (Exception e) {
								throw new IllegalStateException(e);
					}	
					http2.disconnect();
				} else {
					String arguments = pnr;
					pts.addPortUpdate(con, arguments, "Cancel", 9999);
				}
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			
			if(cancelCon) {
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("WelcomePage.jsp");
				requestDispatcher.forward(request, response);
			}	
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("CancelPage.jsp");
			requestDispatcher.forward(request, response);
		}
	}
	public void cancelTicket(String pnr) {
		BookingDetail cancelBd = bs.getBookingByPnr(con, pnr);
		Train cancelTrain = ts.readTrainDetail(con, cancelBd.getTrainId());
		if (cancelBd.getBookingStatus().equals("waiting")) {
			
			boolean cancel = bs.cancelBooking(con, pnr);
			
			if(cancel) {
				//ts.updateTrainSeat(con, 0 - (int)(cancelBd.getCost() / 140), cancelTrain);
				cancelCon = true;
			} 
			
		} else {
			BookingDetail confirmBd = null;
			//Train cancelTrain = ts.readTrainDetail(con, cancelBd.getTrainId());
			boolean cancelCheck = bs.cancelBooking(con, pnr);
			int seats = (int)(cancelBd.getCost() / 140);
			if(cancelCheck) {
				System.out.println("Successfully cancelled");
			}
			ArrayList<BookingDetail> arr = bs.addWaiting(con, "waiting", cancelBd.getTrainId(), cancelBd.getDate());
			for (BookingDetail b : arr) {
				queue.add(b);
			}
			
			for (BookingDetail bd : queue) {
				
				Train train = ts.readTrainDetail(con, bd.getTrainId());
				System.out.println(" TrainId : " + bd.getTrainId() + " train number: " + train.getTrainNumber()); 
				if (cancelBd.getTrainId() == bd.getTrainId()) {
					System.out.println("Exist ticket ");
					if (train.getNoOfSeats() >= (int) (bd.getCost() / 140)) {
						System.out.println("Exist ticket ");
						confirmBd = bd;
						confirmBd.setBookingStatus("confirm");
						queue.remove(confirmBd);
					} else {
						confirmBd = bd;
						confirmBd.setBookingStatus("waiting");
					}
				}
			}
			System.out.println(confirmBd.getBookingStatus());
			if (confirmBd.getBookingStatus().equals("confirm")) {
				boolean check = bs.cancelBooking(con, confirmBd.getPnr());
				Train t = ts.readTrainDetail(con, confirmBd.getTrainId());
				boolean createB = bs.createBooking(con, confirmBd);
				if(createB) {
					//ts.updateTrainSeat(con, (int) (confirmBd.getCost() / 140), t);
					cancelCon = true;
				}
			}
			
		}
	}

}
