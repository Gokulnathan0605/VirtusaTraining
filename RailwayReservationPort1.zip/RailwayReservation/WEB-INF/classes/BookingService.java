

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import java.sql.ResultSetMetaData;
import java.io.*;


import java.sql.Connection;


//MYSQL



public class BookingService {
	static PreparedStatement ps;
	static String sql;
	static BookingDetail bd;
	private PassengerService p = new PassengerService();
	private TrainService ts = new TrainService();
	public boolean createBooking(Connection con, BookingDetail bd) {
		try {
			sql = "INSERT INTO bookingdetail(trainId, passengerId, pnr, cost, date, startingPoint, endingPoint, bookingStatus, startNo, endNo) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setInt(1, bd.getTrainId());
			ps.setInt(2, bd.getPassengerId());
			ps.setString(3, bd.getPnr());
			ps.setFloat(4, bd.getCost());
			ps.setString(5, bd.getDate());
			ps.setString(6, bd.getStartingPoint());
			ps.setString(7, bd.getEndingPoint());
			ps.setString(8, bd.getBookingStatus());
			ps.setInt(9, bd.getStartNo());
			ps.setInt(10, bd.getEndNo());

			int rows = ps.executeUpdate();
			
			if (rows > 0) {
				return true;
			}
			return false;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	public ResultSet getAllBooking(Connection con) throws Exception{
		sql = "SELECT * FROM bookingDetail";
		ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	
	public void createHoldBooking(Connection con, ArrayList<BookingDetail> arr) {
		for(BookingDetail  b : arr) {
			if(getBookingByPnr(con, b.getPnr()) == null) {
				createBooking(con, b);
			} else {
				updateBooking(con, b);
			}
		}
	}
	public ResultSet readAll(Connection con) {
		try {
			sql = "SELECT * FROM bookingdetail";
			ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();
			
			return rs;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	
	public int checkingBookingSeat(Connection con, String date, int trainId) {
		try {
			sql = "SELECT cost FROM bookingdetail WHERE date=? AND trainId=? ";
			ps = con.prepareStatement(sql);
			ps.setString(1, date);
			ps.setInt(2, trainId);
			//ps.setInt(3, "confirm");
			
			ResultSet rs = ps.executeQuery();
			int seatCount = 0;
			while(rs.next()) {
				seatCount += ((int)(rs.getFloat("cost") / 140));
			}
			return seatCount;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public ArrayList<ArrayList<String>> getBookingArray(Connection con, int loginId, String email) {
		try {
			ArrayList<ArrayList<String>> res = new ArrayList<ArrayList<String>>();
			sql = "SELECT * FROM bookingdetail WHERE passengerId=?";
			int lid = p.checkLogin(con, email);
			ps = con.prepareStatement(sql);
			ps.setInt(1, lid);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ArrayList<String> inner = new ArrayList<>();
				Passenger passenger = p.getPassenger(con, loginId);
				inner.add(passenger.getName());
				inner.add(passenger.getEmail());
				inner.add(rs.getString("pnr"));
				Train train = ts.readTrainDetail(con, rs.getInt("trainId"));
				inner.add(String.valueOf(train.getTrainNumber()));
				inner.add(train.getTrainName());
				int cost = (int)(rs.getFloat("cost") / 140);
				inner.add(String.valueOf(cost));
				inner.add(String.valueOf(rs.getFloat("cost")));
				inner.add(rs.getString("bookingStatus"));
				inner.add(rs.getString("startingPoint"));
				inner.add(rs.getString("endingPoint"));
				res.add(inner);
			}
			return res;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/*public static int getBookingId(Connection con, BookingDetail bd) {
		try {
			int id = -1;
			sql = "SELECT * FROM bookingdetail WHERE trainId=? AND passengerId=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, bd.getTrainId());
			ps.setInt(2, bd.getPassengerId());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt("id");
			}
			return id;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}*/

	public boolean cancelBooking(Connection con, String pnr) {
		try {
			sql = "DELETE FROM bookingdetail WHERE pnr=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, pnr);

			int rowsDeleted = ps.executeUpdate();

			if (rowsDeleted > 0) {
				return true;
			}
			return false;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public void createHoldCancel(Connection con, ArrayList<String> arr) {
		for(String pnr : arr) {
			if(getBookingByPnr(con, pnr) != null) {
				cancelBooking(con, pnr);
			}
		}
	}
	public BookingDetail getBookingByPnr(Connection con, String pnr) {
		try {
			sql = "SELECT * FROM bookingDetail WHERE pnr=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, pnr);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				bd = new BookingDetail(rs.getInt("trainId"), rs.getInt("passengerId"), rs.getString("pnr"), rs.getFloat("cost"),
						rs.getString("date"), rs.getString("startingPoint"), rs.getString("endingPoint"),
						rs.getString("bookingStatus"), rs.getInt("startNo"), rs.getInt("endNo"));
			}
			return bd;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	/*public static ArrayList<BookingDetail> readAllDetails(Connection con, int trainId) {
		ArrayList<BookingDetail> arr = new ArrayList<>();
		try {
			sql = "SELECT * FROM bookingDetail WHERE trainId=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, trainId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				arr.add(new BookingDetail(rs.getInt("trainId"), rs.getInt("passengerId"), rs.getString("pnr"),rs.getFloat("cost"),
						rs.getString("date"), rs.getString("startingPoint"), rs.getString("endingPoint"),
						rs.getString("bookingStatus"), rs.getInt("startNo"), rs.getInt("endNo")));
			}
			return arr;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}*/

	public ArrayList<BookingDetail> addWaiting(Connection con, String status, int trainId, String date) {
		ArrayList<BookingDetail> arr = new ArrayList<>();
		try {
			sql = "SELECT * FROM bookingdetail WHERE bookingStatus=? AND trainId=? AND date=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, status);
			ps.setInt(2, trainId);
			ps.setString(3, date);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				arr.add(new BookingDetail(rs.getInt("trainId"), rs.getInt("passengerId"),rs.getString("pnr"), rs.getFloat("cost"),
						rs.getString("date"), rs.getString("startingPoint"), rs.getString("endingPoint"),
						rs.getString("bookingStatus"), rs.getInt("startNo"), rs.getInt("endNo")));
			}
			return arr;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public static BookingDetail readBookingDetail(Connection con, int id) {
		try {
			sql = "SELECT * FROM bookingdetail WHERE passengerId=? ";
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				bd = new BookingDetail(rs.getInt("trainId"), rs.getInt("passengerId"), rs.getString("pnr"),rs.getFloat("cost"),
						rs.getString("date"), rs.getString("startingPoint"), rs.getString("endingPoint"),
						rs.getString("bookingStatus"), rs.getInt("startNo"), rs.getInt("endNo"));
			}
			return bd;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	public static boolean updateBooking(Connection con, BookingDetail bd) {
		try {
			sql = "UPDATE bookingdetail SET bookingStatus=? WHERE pnr=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, bd.getBookingStatus());
			
			ps.setString(2, bd.getPnr());
			
			int rowsAffected = ps.executeUpdate();
			if (rowsAffected > 0) {
				return true;
			}
			return false;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
}