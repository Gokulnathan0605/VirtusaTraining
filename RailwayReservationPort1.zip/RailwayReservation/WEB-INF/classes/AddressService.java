import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.ResultSetMetaData;
import java.io.*;
import java.util.ArrayList;
import java.sql.Connection;


//PSQL



public class AddressService {
	static String sql = "";
	static PreparedStatement st;
	static Address address;

	public  int createAddress(Address address, Connection con) {
		try {
			int id = -1;
			id = checkAddress(address, con);
			if (id == -1) {

				sql = "INSERT INTO addressdetail(street, city, postalCode) VALUES(?, ?, ?)";
				st = con.prepareStatement(sql);
				setValues(address);

				st.executeUpdate();
				return checkAddress(address, con);
			} else {
				return id;
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public ResultSet readAll(Connection con) {
		try {
			sql = "SELECT * FROM addressdetail ";
			st = con.prepareStatement(sql);

			ResultSet rs = st.executeQuery();
			//System.out.println("street : " + rs.getString("street") + " city: " + rs.getString("city") + " postalcode: " + rs.getInt("postalCode"));
			
			return rs;
				
			
			
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	/*public void setPSQLAddress(Connection con, ArrayList<Address> addList) {
		try {
			String sql1 = "TRUNCATE TABLE addressdetail;";
			st = con.prepareStatement(sql1);
			st.execute(sql1);
			for(Address ad : addList) {
				sql="INSERT INTO addressdetail(street, city, postalCode) VALUES(?, ?, ?)";
				st = con.prepareStatement(sql);
				setValues(ad);
				st.executeUpdate();	
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public void importAddressCsv(Connection con) {
		BufferedReader reader = null;
		try {
			ArrayList<Address> addList = new ArrayList<>();
			String line = "";
			reader = new BufferedReader(new FileReader("C://Program Files//Apache Software Foundation//CSV//PSQL//addressdetail.csv"));
			reader.readLine();
			while((line = reader.readLine()) != null) {
				String[] fields = line.split(",");
				
				if(fields.length > 0) {
					address.setId(Integer.parseInt(fields[0]));
					address.setStreet(fields[1]);
					address.setCity(fields[2]);
					address.setPostalCode(Integer.parseInt(fields[3]));
					addList.add(address);
				}
			}
			setPSQLAddress(con, addList);
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public  void exportAddressCsv(Connection con) {
		ResultSet rs = readAll(con);
		FileWriter fw = null;
		try {
			fw = new FileWriter("C://Program Files//Apache Software Foundation//CSV//MYSQL//addressdetail.csv");
			fw.append("id, street, city, postalCode");
			fw.append("\n");
			while(rs.next()) {
				fw.append(String.valueOf(rs.getInt("id")));
				fw.append(",");
				fw.append(rs.getString("street"));
				fw.append(",");
				fw.append(rs.getString("city"));
				fw.append(",");
				fw.append(String.valueOf(rs.getInt("postalCode")));
				fw.append("\n");
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			try {
				//fw.flush();
				fw.close();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			
			}
		}
		
	}*/
	
	public int checkAddress(Address address, Connection con) {
		try {
			sql = "SELECT * FROM addressdetail WHERE street=? AND city=? AND postalCode=?";
			st = con.prepareStatement(sql);
			setValues(address);

			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				return rs.getInt("id");
			}
			return -1;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public  Address readAddress(int id, Connection con) {
		try {
			sql = "SELECT * FROM addressdetail WHERE id=?";
			st = con.prepareStatement(sql);

			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			//System.out.println("street : " + rs.getString("street") + " city: " + rs.getString("city") + " postalcode: " + rs.getInt("postalCode"));
			if (rs.next()) {
				return new Address(rs.getString("street"), rs.getString("city"), rs.getInt("postalCode"));
				
			}
			return address;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	public int updateAddress(Address address, Connection con) {
		try {
			String sql = "UPDATE addressdetail SET street=? , city=? , postalCode=?";
			st = con.prepareStatement(sql);
			setValues(address);
			int rowAffected = st.executeUpdate();
			if (rowAffected > 0) {
				int id = checkAddress(address,con);
				return id;
			}
			return 0;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public static void setValues(Address address) {
		try {
			st.setString(1, address.getStreet());
			st.setString(2, address.getCity());
			st.setInt(3, address.getPostalCode());
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
}