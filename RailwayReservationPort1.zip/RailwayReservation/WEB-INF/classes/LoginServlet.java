
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

import java.sql.*;

import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

import java.nio.charset.StandardCharsets;
import org.json.simple.parser.*;
import org.json.simple.*;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PassengerService ps = new PassengerService();
	private AddressService as = new AddressService();
	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private InputStream is;
	private Login login;
	private Connection con;
	private int passengerNumber, loginId;
	private boolean conPassenger;
	private PassengerServlet pSer = new PassengerServlet();
	private PortTransferService pts = new PortTransferService();
	private ServletContext ctx ;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				
		con = MysqlConnection.getConnection();
		if(request.getQueryString() != null) {
			String json="";
			System.out.println("Connection from another port");
			try {
				if(request.getParameter("query").equals("allHoldLogin")) {
					int port = Integer.parseInt(request.getParameter("port"));
					ResultSet rs = pts.getPortUpdate(con, "Login", port);
					JSONArray arr = new JSONArray();
					//System.out.println(port + "sad " + rs.getFetchSize());
					
					while(rs.next()) {
						
						String arguments = rs.getString("parameters");
						String[] res = arguments.split(",");
						System.out.println(arguments);
						JSONObject obj = new JSONObject();
						obj.put("password",res[1]);
						obj.put("id",rs.getInt("id"));
						obj.put("email",res[0]);		
						arr.add(obj);
						pts.deletePortUpdate(con, rs.getInt("id"));
					}
					
					json = arr.toString();
					System.out.println(json);
				}
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				out.print(json);
				out.flush();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
		} else {		
			String inputLine;
			JSONParser parser = new JSONParser();
			ArrayList<Login> arrLog = new ArrayList<>();
			try {
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					System.out.println("Welcome to 9999");
					URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/LoginServlet?port=8080&query=allHoldLogin");
					URLConnection yc = urlLogin.openConnection();
					BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
					
					while ((inputLine = in.readLine()) != null) {     
						JSONArray addObj = (JSONArray) parser.parse(inputLine);
						for (Object o : addObj) {
							JSONObject obj = (JSONObject) o;
							Long l1 = new Long((Long)obj.get("id"));
							Login log = new Login((String)obj.get("email"),(String)obj.get("password"));
							log.setId(l1.intValue());
							arrLog.add(log);
					 
						}
					}
				}
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/LoginServlet?port=8080&query=allHoldLogin");
					URLConnection yc1 = urlLogin1.openConnection();
					BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
					while ((inputLine = in1.readLine()) != null) {     
						JSONArray addObj = (JSONArray) parser.parse(inputLine);
						for (Object o : addObj) {
							JSONObject obj = (JSONObject) o;
							Long l1 = new Long((Long)obj.get("id"));
							Login log = new Login((String)obj.get("email"),(String)obj.get("password"));
							log.setId(l1.intValue());
							arrLog.add(log);
					 
						}
					}
				}
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			ps.createHoldLogin(con, arrLog);
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("Login.jsp");
		requestDispatcher.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Login newLogin = null;
		con = MysqlConnection.getConnection();
		request.getSession().setAttribute("className",this.getClass().getSimpleName());				
		if(request.getQueryString() != null) {
			try {
				String query = (String)request.getParameter("query");
				if(query.equals("updateLogin")) {
					
					System.out.println("query in url");
					String newEmail = (String)request.getParameter("newEmail");
					String newPass = (String)request.getParameter("newPass");
					newLogin = new Login(newEmail, newPass);
					System.out.println(newEmail + " " + newPass);
				}
				System.out.println("query not in url");
			
				String em = request.getParameter("newEmail");
				String pass = request.getParameter("newPass");
				System.out.println("res ans : " + em + " " +pass);
				int newLoginId = ps.createLogin(con, em, pass);
				System.out.println("new Id: " + newLoginId);
				
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
		} else {
			
			
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			login = new Login(email, password);
			request.getSession().setAttribute("email",email);		
			request.getSession().setAttribute("password",password);				
			loginId = ps.createLogin(con ,email, password);
			login.setId(loginId);
			
			try { 
				
				
				//System.out.println(http1.getResponseCode());
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					String u1 = "http://www.kiruthicrailwayReservation.com:8081/LoginServlet?query=updateLogin&newEmail="+email+"&newPassword="+password;
					

					pts.addPortUpdate(con, email + ","+password, "Login", 8081);
												

					URLConnection url1 = new URL(u1).openConnection();
					HttpURLConnection http1 = (HttpURLConnection)url1;
					http1.setRequestMethod("POST");
					http1.setDoOutput(true);
					try {
						int count = 0;
						while((count = pts.checkPortUpdate(con, "Login",8081)) != 0) {
							ResultSet rs = pts.getPortUpdate(con, "Login", 8081);
							String arguments="";
							if(rs.next()) {
								arguments = rs.getString("parameters");
							}
							pts.deletePortUpdate(con, rs.getInt("id"));
							String[] res = arguments.split(",");
							Map<String, String> arg = new HashMap<>();
							arg.put("newEmail",res[0]);
							arg.put("newPass",res[1]);
							StringJoiner sj = new StringJoiner("&");
							for(Map.Entry<String, String> entry : arg.entrySet()) {
								sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
										+ URLEncoder.encode(entry.getValue(), "UTF-8"));
							}
							byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
							int length = out.length;
							
							http1.setFixedLengthStreamingMode(length);
							http1.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
							http1.connect();
							try(OutputStream os = http1.getOutputStream()) {
								os.write(out);
							} catch (Exception e) {
								throw new IllegalStateException(e);
							}
						}
					}catch (Exception e) {
								throw new IllegalStateException(e);
					}
					http1.disconnect();
				} else {
					String arguments = email + "," + password;
					pts.addPortUpdate(con, arguments, "Login", 8081);
					
				}
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					String u2 = "http://www.kiruthicrailwayReservation.com:9999/LoginServlet?query=updateLogin&newEmail="+email+"&newPassword="+password;
					

					pts.addPortUpdate(con, email + ","+password, "Login", 9999);


					URLConnection url2 = new URL(u2).openConnection();
					HttpURLConnection http2 = (HttpURLConnection)url2;
					http2.setRequestMethod("POST");
					http2.setDoOutput(true);
					try {
						int count = 0;
						while((count = pts.checkPortUpdate(con, "Login",9999)) != 0) {
							ResultSet rs = pts.getPortUpdate(con, "Login", 9999);
							String arguments="";
							if(rs.next()) {
								arguments = rs.getString("parameters");
							}
							pts.deletePortUpdate(con, rs.getInt("id"));
							String[] res = arguments.split(",");
							Map<String, String> arg = new HashMap<>();
							arg.put("newEmail",res[0]);
							arg.put("newPass",res[1]);
							StringJoiner sj = new StringJoiner("&");
							for(Map.Entry<String, String> entry : arg.entrySet()) {
								sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
										+ URLEncoder.encode(entry.getValue(), "UTF-8"));
							}
							byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
							int length = out.length;
							
							http2.setFixedLengthStreamingMode(length);
					
							http2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
							http2.connect();
							try(OutputStream os = http2.getOutputStream()) {
								os.write(out);
							} catch (Exception e) {
								throw new IllegalStateException(e);
							}
							
						}
					
					}catch (Exception e) {
								throw new IllegalStateException(e);
					}
					
					http2.disconnect();
					
				} else {
					String arguments = email + "," + password;
					pts.addPortUpdate(con, arguments, "Login", 9999);
					
				}
	
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			//pSer.getDataFromPort2();
			if(passengerNumber == 0) {
				checkingPassenger(login);
			}
			if(conPassenger) {
				System.out.println("passing checking passenger");
				loginId = ps.checkLogin(con, email);
					Passenger p = ps.getPassenger(con, loginId);
					Address a = as.readAddress(p.getAddressId(), con);
					System.out.println("passenger Name : " + p.getName() + "address: " + a.getCity());
					request.getSession().setAttribute("pasName",p.getName());
					request.getSession().setAttribute("pasDob", p.getDob());
					request.getSession().setAttribute("addStreet",a.getStreet());
					request.getSession().setAttribute("addCity", a.getCity());
					request.getSession().setAttribute("addPostalCode", a.getPostalCode());
					
			} else {
				
			}
			//request.getSession().setAttribute("className",this.getClass().getSimpleName());
			System.out.println("failed to check passenger");
			request.getSession().setAttribute("loginId",loginId);
					System.out.println("failed to check passenger" + "loginId: " + (int)request.getSession().getAttribute("loginId"));
			String logout = request.getParameter("logout");
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("passengerLogin.jsp");
			requestDispatcher.forward(request, response);
		}
	}
	public void checkingPassenger(Login l) {
		passengerNumber = ps.checkPassenger(con, l.getEmail());
		System.out.println(passengerNumber);
		if(passengerNumber > 0) {
			conPassenger = true;
				
		} else {
			
			conPassenger = false;
		}
	}

}
