

import java.sql.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import javax.xml.xpath.*;
public class MysqlConnection {
	private static Connection con;
	static String url1 = "jdbc:postgresql://localhost:5432/railwaydb";
	//static String url2 = "jdbc:postgresql://localhost:5432/secondDb";
	static String username = "postgres";
	static String password = "root";
	private static TrainService ts = new TrainService();
	private static AddressService as = new AddressService();
	private static PassengerService ps = new PassengerService();
	private static BookingService bs = new BookingService();
	
	public static Connection getConnection() {
		File file = new File("C:\\Program Files\\Apache Software Foundation\\Port1\\conf\\server.xml");   
		int portNumber = getTomcatPortFromConfigXml(file);
		System.out.println("port Number : " + portNumber + "\n");
		
			try {
				System.out.println("railwaydb PSQL");
				Class.forName("org.postgresql.Driver");
				con = DriverManager.getConnection(url1, username, password);
				/*ts.importTrainCsv(con);
				ps.importPassengerCsv(con);
				bs.importBookingCsv(con);
				ps.importLoginCsv(con);
				as.importAddressCsv(con);
				System.out.println(con);*/
				return con;
			} catch (Exception e) {
				throw new IllegalStateException(e);
			} finally {
				/*ts.exportTrainCsv(con);
				ps.exportPassengerCsv(con);
				bs.exportBookingCsv(con);
				ps.exportLoginCsv(con);
				as.exportAddressCsv(con);*/
				//closeConnection();
			}
		
		
	}

	public static void closeConnection() {

		try {
			con.close();
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	
	public static Integer getTomcatPortFromConfigXml(File serverXml) {
	   Integer port;
	   try {
		  DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		  domFactory.setNamespaceAware(true);
		  DocumentBuilder builder = domFactory.newDocumentBuilder();
		  Document doc = builder.parse(serverXml);
		  XPathFactory factory = XPathFactory.newInstance();
		  XPath xpath = factory.newXPath();
		  XPathExpression expr = xpath.compile
			("/Server/Service[@name='Catalina']/Connector[count(@scheme)=0]/@port[1]");
		  String result = (String) expr.evaluate(doc, XPathConstants.STRING);
		  port =  result != null && result.length() > 0 ? Integer.valueOf(result) : null;
	   } catch (Exception e) {
		 port = null;
	   }
	   return port;
	}
	public static void main(String[] args) {
		System.out.println(getConnection());
	}
}