import java.io.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.*;


//MYSQL


public class TrainService {
	Train train;
	private PreparedStatement ps;
	public ResultSet readAll(Connection con) {
		try {
			String sql = "SELECT * FROM traindetails;";
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			return rs;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}
	
	public void setPSQLTrain(Connection con, ArrayList<Train> tList) {
		
		try {
			String sql1 = "TRUNCATE TABLE traindetails;";
			ps = con.prepareStatement(sql1);
			ps.execute(sql1);
			for(Train t : tList) {
				String sql = " INSERT INTO traindetails(trainName, trainNumber, noOfSeats, areas) VALUES(?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setString(1,t.getTrainName());
				ps.setInt(2,t.getTrainNumber());
				ps.setInt(3,t.getNoOfSeats());
				ps.setString(4,t.getRouteAreas());
				int rows = ps.executeUpdate();
				//System.out.println(rows);
			}
		}catch (Exception e) {
			throw new IllegalStateException(e);
		}
			
		
	}
	
	public void importTrainCsv(Connection con) {
		BufferedReader reader = null;
		try {
			ArrayList<Train> tList = new ArrayList<>();
			String line = "";
			Train t = null;
			reader = new BufferedReader(new FileReader("C://Program Files//Apache Software Foundation//CSV//PSQL//traindetails.csv"));
			reader.readLine();
			while((line = reader.readLine()) != null) {
				
				
				String[] fields = line.split(",");
				//System.out.println(line + " " + Arrays.toString(fields) + " " + fields[1]);
				if(fields.length > 0) {
					/*t.setTrainName(fields[1]);
					t.setTrainNumber(Integer.parseInt(fields[2]));
					t.setNoOfSeats(Integer.parseInt(fields[3]));
					t.setRouteAreas(fields[4]);*/
					t = new Train(fields[1], Integer.parseInt(fields[2]), Integer.parseInt(fields[3]),fields[4] );
					//setPSQLTrain(con, t);
				}
				//System.out.println(t.getTrainName());
				tList.add(t);
			}
			setPSQLTrain(con, tList);
		}
		catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	public  void exportTrainCsv(Connection con) {
		ResultSet rs = readAll(con);
		FileWriter fw = null;
		try {
			fw = new FileWriter("C://Program Files//Apache Software Foundation//CSV//MYSQL//traindetails.csv");
			fw.append("id, trainName, trainNumber, noOfSeats, areas");
			fw.append("\n");
			while(rs.next()) {
				fw.append(String.valueOf(rs.getInt("id")));
				fw.append(",");
				fw.append(rs.getString("trainName"));
				fw.append(",");
				fw.append(String.valueOf(rs.getInt("trainNumber")));
				fw.append(",");
				fw.append(String.valueOf(rs.getInt("noOfSeats")));
				fw.append(",");
				fw.append(rs.getString("areas"));
				fw.append("\n");
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			try {
				//fw.flush();
				fw.close();
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}
		
	}
	
	public Train readTrainDetail(Connection con, int trainId) {

		try {
			String sql = "SELECT * FROM traindetails WHERE id=?;";
			//int id = readTrainId(con, trainId);
			ps = con.prepareStatement(sql);
			ps.setInt(1, trainId);
			System.out.println("Hello " + trainId + " readTrainDetail");
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				train = new Train(rs.getString("trainName"), rs.getInt("trainNumber"), rs.getInt("noOfSeats"),
						rs.getString("areas"));
			}
			System.out.println(train.getTrainName() + " " + train.getTrainNumber());
			return train;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	public int readTrainId(Connection con, int trainNumber) {

		try {
			String sql = "SELECT * FROM traindetails WHERE trainNumber=?";

			ps = con.prepareStatement(sql);
			ps.setInt(1, trainNumber);
			ResultSet rs = ps.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("id");
			}
			return -1;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	public void updateTrainSeat(Connection con, int seats, Train train) {
		try {
			String sql = "UPDATE traindetails SET noOfSeats=? WHERE trainNumber=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, train.getNoOfSeats() - seats);
			ps.setInt(2, train.getTrainNumber());
			ps.executeUpdate();
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

}
