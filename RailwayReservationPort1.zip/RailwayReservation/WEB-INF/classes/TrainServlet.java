

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class TrainServlet
 */
@WebServlet("/TrainServlet")
public class TrainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TrainService ts = new TrainService(); 
    private BookingService bs = new BookingService();
	private BookingServlet bSer = new BookingServlet();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection con = MysqlConnection.getConnection();
		HttpSession session = request.getSession(true);
		ResultSet rs = ts.readAll(con);
		session.setAttribute("results", rs);
		RequestDispatcher dispatcher = request.getRequestDispatcher("TrainList.jsp");
		dispatcher.forward(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con = MysqlConnection.getConnection();
		String date = request.getParameter("boardingDate");
		String selected = request.getParameter("trainSelection");
		request.getSession().setAttribute("trainNumber", selected);
		request.getSession().setAttribute("bDate",date);
		int trainId = ts.readTrainId(con,Integer.parseInt(selected));
		Train t = ts.readTrainDetail(con, trainId);
		//int count = t.getNoOfSeats();
		
		int seatCount = bs.checkingBookingSeat(con, (String)request.getSession().getAttribute("bDate"), trainId);
		request.getSession().setAttribute("count", (t.getNoOfSeats() ) - seatCount);
		request.getSession().setAttribute("areas", t.getRouteAreas().split("/"));

		RequestDispatcher dispatcher = request.getRequestDispatcher("BookTicket.jsp");
		dispatcher.forward(request, response);
	}

}
