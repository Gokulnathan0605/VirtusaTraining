import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.*;
import java.io.File;  
import java.util.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


public class Test {

	 public static void updateNodeValue(Document doc) {
		 ArrayList<Passenger> arrp = new ArrayList<>();
		arrp.add(new Passenger("Kiruthic", "21-09-2000", 01, "kiruthic2000@gmail.com"));
		arrp.add(new Passenger("Kiruthic P", "21-09-2000", 01, "kiruthic2109@gmail.com"));
		 NodeList nodeListPassenger = doc.getElementsByTagName("passenger");
		 
		for(int i = 0; i < nodeListPassenger.getLength(); i++) {
			
			Node node = nodeListPassenger.item(i);
			System.out.println("Node name: " + node.getNodeName());
			
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				Element e = (Element) node;
				 e.getElementsByTagName("id").item(0).setTextContent("002");
				
				e.getElementsByTagName("passengerName").item(0).setTextContent(arrp.get(0).getName());
				e.getElementsByTagName("dateOfBirth").item(0).setTextContent(arrp.get(0).getDob());
				e.getElementsByTagName("addressId").item(0).setTextContent(String.valueOf(arrp.get(0).getAddressId()));
				e.getElementsByTagName("email").item(0).setTextContent(arrp.get(0).getEmail());
				//e.getElementsByTagName("loginId").item(0).setTextContent("01");
			}
			
		}
	 }

	public static void printXML(Document doc) {
		System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
		NodeList nodeListPassenger = doc.getElementsByTagName("passenger");
		for(int i = 0; i < nodeListPassenger.getLength(); i++) {
			Node node = nodeListPassenger.item(i);
			System.out.println("Node name: " + node.getNodeName());
			
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				Element e = (Element) node;
				
				System.out.println("id :" + e.getElementsByTagName("id").item(0).getTextContent());
				System.out.println("Name :" + e.getElementsByTagName("passengerName").item(0).getTextContent());
				System.out.println("Dob :" + e.getElementsByTagName("dateOfBirth").item(0).getTextContent());
				System.out.println("address Id :" + e.getElementsByTagName("addressId").item(0).getTextContent());
				System.out.println("email :" + e.getElementsByTagName("email").item(0).getTextContent());
				System.out.println("Login Id :" + e.getElementsByTagName("loginId").item(0).getTextContent());
			}
		}NodeList nodeListLogin = doc.getElementsByTagName("login");
		for(int i = 0; i < nodeListLogin.getLength(); i++) {
			Node node = nodeListLogin.item(i);
			System.out.println("Node name: " + node.getNodeName());
			if(node.getNodeType() == Node.ELEMENT_NODE) {
				Element e = (Element) node;
				System.out.println("id :" + e.getElementsByTagName("id").item(0).getTextContent());
				
				System.out.println("email :" + e.getElementsByTagName("email").item(0).getTextContent());
				System.out.println("password :" + e.getElementsByTagName("password").item(0).getTextContent());
			}
		}
	}		
	 public static void main(String args[]) throws Exception{
		
		File file = new File("C:\\Program Files\\Apache Software Foundation\\Port1\\conf\\tables.xml");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(file);
		doc.getDocumentElement().normalize();
		updateNodeValue(doc);
		doc.getDocumentElement().normalize();
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(file);
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
		System.out.println("XML file updated successfully");
		Document doc1 = db.parse(file);
		doc1.getDocumentElement().normalize();
		printXML(doc1);
	 }
}