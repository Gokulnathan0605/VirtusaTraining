import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;

import java.nio.charset.StandardCharsets;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.parser.*;

import org.json.simple.*;


/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookingService bs = new BookingService();
	private TrainService ts = new TrainService();
	private int bookingId;
	static Queue<BookingDetail> queue = new LinkedList<>();
	private Train train;
	private PassengerService ps = new PassengerService();
	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private InputStream is;
	private Connection con = MysqlConnection.getConnection();
	private PortTransferService pts = new PortTransferService();


	public BookingServlet() {
		super();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


			String email = (String)request.getSession().getAttribute("email");
			int loginId = ps.checkLogin(con, email);
		if(request.getParameter("query").equals("allHoldBooking")) {
			String json="";
			try {
				if(request.getParameter("query").equals("allHoldBooking")) {
					int port = Integer.parseInt(request.getParameter("port"));
					ResultSet rs = pts.getPortUpdate(con, "Booking", port);
					JSONArray arr = new JSONArray();
					while(rs.next()) {
						String arguments = rs.getString("parameters");
						String[] res = arguments.split(",");
						JSONObject obj = new JSONObject();
						obj.put("id", rs.getInt("id"));
						obj.put("trainId",res[0]);
						obj.put("loginId",res[1]);
						obj.put("noOfSeats",res[2]);
						obj.put("boardingDate",res[3]);
						obj.put("startingPoint",res[4]);
						obj.put("endingPoint",res[5]);

						arr.add(obj);
						pts.deletePortUpdate(con, rs.getInt("id"));
					}

					json = arr.toString();
				}
				PrintWriter out = response.getWriter();
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				out.print(json);
				out.flush();
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}else if(request.getParameter("query").equals("seeTicket")){
			String inputLine;
			JSONParser parser = new JSONParser();
			ArrayList<BookingDetail> arr = new ArrayList<>();
			try {
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					System.out.println("Welcome to 9999");
					URL urlLogin = new URL("http://www.kiruthicrailwayreservation.com:9999/BookingServlet?port=8080&query=allHoldBooking");
					URLConnection yc = urlLogin.openConnection();
					BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));

					while ((inputLine = in.readLine()) != null) {
						JSONArray addObj = (JSONArray) parser.parse(inputLine);
						for (Object o : addObj) {
							JSONObject obj = (JSONObject) o;
							Long l1 = new Long((Long)obj.get("id"));
							Long trainId = new Long((Long)obj.get("trainId"));
							Long logId = new Long((Long)obj.get("loginId"));
							Long noOfSeats = new Long((Long)obj.get("noOfSeats"));
								BookingDetail b = new BookingDetail(trainId.intValue(),logId.intValue(), noOfSeats.intValue(),
								(String)obj.get("boardingDate"), (String)obj.get("startingPoint"),(String)obj.get("endingPoint"));

							arr.add(b);

						}
					}
				}
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					URL urlLogin1 = new URL("http://www.kiruthicrailwayreservation.com:8081/BookingServlet?port=8080&query=allHoldBooking");
					URLConnection yc1 = urlLogin1.openConnection();
					BufferedReader in1 = new BufferedReader(new InputStreamReader(yc1.getInputStream()));
					while ((inputLine = in1.readLine()) != null) {
						JSONArray addObj = (JSONArray) parser.parse(inputLine);
						for (Object o : addObj) {
							JSONObject obj = (JSONObject) o;
							Long l1 = new Long((Long)obj.get("id"));
							Long trainId = new Long((Long)obj.get("trainId"));
							Long logId = new Long((Long)obj.get("loginId"));
							Long noOfSeats = new Long((Long)obj.get("noOfSeats"));
								BookingDetail b = new BookingDetail(trainId.intValue(),logId.intValue(), noOfSeats.intValue(),
								(String)obj.get("boardingDate"), (String)obj.get("startingPoint"),(String)obj.get("endingPoint"));

							arr.add(b);

						}
					}
				}
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			bs.createHoldBooking(con, arr);

			int trainNumber = Integer.parseInt((String) request.getSession().getAttribute("trainNumber"));
			ArrayList<ArrayList<String>> bookingArray = bs.getBookingArray(con, loginId, email);
			int trainId = ts.readTrainId(MysqlConnection.getConnection(), trainNumber);
			train = ts.readTrainDetail(MysqlConnection.getConnection(), trainId);
			int seatCount = bs.checkingBookingSeat(con, (String)request.getSession().getAttribute("bDate"), trainId);
			//request.getSession().setAttribute("areas", train.getRouteAreas().split(","));
			request.getSession().setAttribute("count",(train.getNoOfSeats()) - seatCount);
			request.getSession().setAttribute("ticketArray", bookingArray);


			RequestDispatcher dispatcher = request.getRequestDispatcher("SeeTicket.jsp");
			dispatcher.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				
		if(request.getQueryString() != null) {
			System.out.println(request.getQueryString().toString());
			try {
				String query = request.getParameter("query");
				System.out.println("query = " + query);

				if(query.equals("updateBooking")) {
					System.out.println("hello ");
					int trainId = Integer.parseInt(request.getParameter("trainId"));
					int logId = Integer.parseInt(request.getParameter("logId"));
					int noOfSeats = Integer.parseInt(request.getParameter("noOfSeats"));
					String boardDate = request.getParameter("boardingDate");
					String startPoint = request.getParameter("boardingPoint");
					String endPoint = request.getParameter("destinationPoint");
					String pnr = request.getParameter("pnr");
					System.out.println(trainId + ","+logId+","+noOfSeats+","+boardDate+","+startPoint+","+endPoint + "," + pnr);
					BookingDetail b = new BookingDetail(trainId, logId, noOfSeats, boardDate, startPoint, endPoint,pnr);
					System.out.println(b.getBookingStatus() + " status " + b.getStartNo());
					boolean check = bs.createBooking(con, b);
					System.out.println(check);
				}
			}catch (Exception e) {
				throw new IllegalStateException(e);
			}
		} else {
			int noOfSeats = Integer.parseInt(request.getParameter("noOfSeats"));
			String boardingPoint = request.getParameter("boardingPoint");
			String destinationPoint = request.getParameter("destinationPoint");
			String boardingDate = request.getParameter("boardingDate");
			int trainNumber = Integer.parseInt((String) request.getSession().getAttribute("trainNumber"));

			int id = ts.readTrainId(con, trainNumber);
			String email = (String) request.getSession().getAttribute("email");
			int loginId = ps.checkLogin(con, email);
			BookingDetail bd = new BookingDetail(id,loginId, noOfSeats, boardingDate, boardingPoint,
					destinationPoint);

			try {
				if(pts.hostAvailabilityCheck("0.0.0.0",8081)) {
					String u1 = "http://www.kiruthicrailwayReservation.com:8081/BookingServlet?query=updateBooking&trainId="+id+"&logId="+loginId+
								"&noOfSeats="+noOfSeats+"&boardingDate="+boardingDate+"&boardingPoint="+boardingPoint+"&destinationPoint="+destinationPoint+"&pnr="+bd.getPnr();
					

					pts.addPortUpdate(con, id + ","+loginId+","+noOfSeats+","+boardingDate+","+boardingPoint+","+destinationPoint+","+bd.getPnr(), "Booking", 8081);
					URLConnection url1 = new URL(u1).openConnection();
					HttpURLConnection http1 = (HttpURLConnection)url1;
					http1.setRequestMethod("POST");
					http1.setDoOutput(true);
					try {
						int count = 0;
						while((count = pts.checkPortUpdate(con, "Booking",8081)) != 0) {
							ResultSet rs = pts.getPortUpdate(con, "Booking", 8081);
							String arguments="";
							if(rs.next()) {
								arguments = rs.getString("parameters");
							}
							
							pts.deletePortUpdate(con, rs.getInt("id"));
							String[] res = arguments.split(",");
							System.out.println(arguments + " " + Arrays.toString(res));
							Map<String, String> arg = new HashMap<>();
							arg.put("trainId",res[0]);
							arg.put("loginId",res[1]);
							arg.put("noOfSeats",res[2]);
							arg.put("boardingDate",res[3]);
							arg.put("startingPoint",res[4]);
							arg.put("endingPoint",res[5]);
							StringJoiner sj = new StringJoiner("&");
							for(Map.Entry<String, String> entry : arg.entrySet()) {
								sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
										+ URLEncoder.encode(entry.getValue(), "UTF-8"));
							}
							byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
							int length = out.length;
							System.out.println(sj);
							http1.setFixedLengthStreamingMode(length);
							http1.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
							http1.connect();
							System.out.println("connected");
							try(OutputStream os = http1.getOutputStream()) {
								os.write(out);
								System.out.println("sent");
							} catch (Exception e) {
								throw new IllegalStateException(e);
							}
						}
					}catch (Exception e) {
								throw new IllegalStateException(e);
					}
					http1.disconnect();

				} else {
					String arguments = id + ","+loginId+","+noOfSeats+","+boardingDate+","+boardingPoint+","+destinationPoint+","+bd.getPnr();
					pts.addPortUpdate(con, arguments, "Booking", 8081);

				}
				if(pts.hostAvailabilityCheck("0.0.0.0",9999)) {
					String u2 = "http://www.kiruthicrailwayReservation.com:9999/BookingServlet?query=updateBooking&trainId="+id+"&logId="+loginId+
								"&noOfSeats="+noOfSeats+"&boardingDate="+boardingDate+"&boardingPoint="+boardingPoint+"&destinationPoint="+destinationPoint+"&pnr="+bd.getPnr();
					

					pts.addPortUpdate(con,id + ","+loginId+","+noOfSeats+","+boardingDate+","+boardingPoint+","+destinationPoint+","+bd.getPnr(), "Booking", 9999);

					URLConnection url2 = new URL(u2).openConnection();
					HttpURLConnection http2 = (HttpURLConnection)url2;
					http2.setRequestMethod("POST");

					http2.setDoOutput(true);
					
					try {
						int count = 0;
						while((count = pts.checkPortUpdate(con, "Booking",9999)) != 0) {
							ResultSet rs = pts.getPortUpdate(con, "Booking", 9999);
							String arguments="";
							if(rs.next()) {
								arguments = rs.getString("parameters");
							}
							pts.deletePortUpdate(con, rs.getInt("id"));
							String[] res = arguments.split(",");
							Map<String, String> arg = new HashMap<>();
							arg.put("trainId",res[0]);
							arg.put("loginId",res[1]);
							arg.put("noOfSeats",res[2]);
							arg.put("boardingDate",res[3]);
							arg.put("startingPoint",res[4]);
							arg.put("endingPoint",res[5]);
							StringJoiner sj = new StringJoiner("&");
							for(Map.Entry<String, String> entry : arg.entrySet()) {
								sj.add(URLEncoder.encode(entry.getKey(),"UTF-8")+"="
										+ URLEncoder.encode(entry.getValue(), "UTF-8"));
							}
							byte[] out = sj.toString().getBytes(StandardCharsets.UTF_8);
							int length = out.length;

							http2.setFixedLengthStreamingMode(length);

							http2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

							http2.connect();
							try(OutputStream os = http2.getOutputStream()) {
								os.write(out);
							} catch (Exception e) {
								throw new IllegalStateException(e);
							}

						}
						

					}catch (Exception e) {
								throw new IllegalStateException(e);
					}
					http2.disconnect();
				} else {
					String arguments = id + ","+loginId+","+noOfSeats+","+boardingDate+","+boardingPoint+","+destinationPoint+","+bd.getPnr();
					pts.addPortUpdate(con, arguments, "Booking", 9999);

				}

			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
			boolean check = bs.createBooking(con, bd);


			if(check) {
				train = ts.readTrainDetail(con, id);
				//ts.updateTrainSeat(con, noOfSeats, train);
				RequestDispatcher dispatcher = request.getRequestDispatcher("WelcomePage.jsp");
				dispatcher.forward(request, response);
			} else {

				RequestDispatcher dispatcher = request.getRequestDispatcher("BookTicket.jsp");
					dispatcher.forward(request, response);
			}
		}
	}

}
